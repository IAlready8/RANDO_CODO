// Reusable card component

const Card = ({
  children,
  title,
  subtitle,
  icon,
  action,
  footer,
  hover = true,
  bordered = true,
  className = '',
  onClick
}) => {
  const cardClasses = `
    bg-darklight 
    rounded-xl 
    p-4 
    ${bordered ? 'border border-gray-700' : ''} 
    ${hover ? 'transition-all duration-300 hover:border-primary hover:-translate-y-1 hover:shadow-lg' : ''} 
    ${onClick ? 'cursor-pointer' : ''} 
    ${className}
  `;

  return (
    <div className={cardClasses} onClick={onClick} data-id="g2ysdcgz1" data-path="components/Card.js">
      {(title || icon || action) &&
      <div className="flex items-center justify-between mb-4" data-id="tqx8501pu" data-path="components/Card.js">
          <div className="flex items-center" data-id="ilfgcq1b7" data-path="components/Card.js">
            {icon && <div className="mr-3 text-primary" data-id="rvs3kgtrt" data-path="components/Card.js">{icon}</div>}
            <div data-id="umhh20dv5" data-path="components/Card.js">
              {title && <h3 className="font-semibold text-white" data-id="136t3p7qe" data-path="components/Card.js">{title}</h3>}
              {subtitle && <p className="text-sm text-gray-400" data-id="isy96vi1b" data-path="components/Card.js">{subtitle}</p>}
            </div>
          </div>
          {action && <div data-id="81b91j4k8" data-path="components/Card.js">{action}</div>}
        </div>
      }
      
      <div className={`${footer ? 'mb-4' : ''}`} data-id="ok4ek70x2" data-path="components/Card.js">
        {children}
      </div>
      
      {footer &&
      <div className="pt-3 border-t border-gray-700" data-id="7yrxiwqha" data-path="components/Card.js">
          {footer}
        </div>
      }
    </div>);

};

// Stats Card for displaying analytics
const StatsCard = ({
  title,
  value,
  change,
  icon,
  isPositive,
  className = ''
}) => {
  return (
    <Card
      className={`stats-card ${className}`}
      icon={icon}
      title={title}>

      <div className="stats-value text-white" data-id="ejef9am7n" data-path="components/Card.js">{value}</div>
      {change !== undefined &&
      <div className={`stats-change ${isPositive ? 'positive' : 'negative'} flex items-center`} data-id="cxw8m5wop" data-path="components/Card.js">
          {isPositive ?
        <i className="fas fa-arrow-up mr-1" data-id="pwwbqunl3" data-path="components/Card.js"></i> :

        <i className="fas fa-arrow-down mr-1" data-id="kqoej7axq" data-path="components/Card.js"></i>
        }
          {change}
        </div>
      }
    </Card>);

};