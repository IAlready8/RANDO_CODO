// Component for selecting a category

const CategorySelector = ({
  availableCategories = [],
  selectedCategory = null,
  onCategorySelect,
  onCategoryCreate
}) => {
  const { useState } = React;
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [showCreateField, setShowCreateField] = useState(false);
  const [colorPickerOpen, setColorPickerOpen] = useState(false);
  const [selectedColor, setSelectedColor] = useState('#9333ea');

  // Category colors
  const categoryColors = [
  '#9333ea', // Purple
  '#3b82f6', // Blue
  '#ef4444', // Red
  '#22c55e', // Green
  '#f97316', // Orange
  '#14b8a6', // Teal
  '#8b5cf6', // Indigo
  '#ec4899' // Pink
  ];

  // Category icons mapping
  const categoryIcons = {
    'General': 'fa-cube',
    'Creative Writing': 'fa-feather',
    'Technical': 'fa-code',
    'Business': 'fa-briefcase',
    'Marketing': 'fa-bullhorn',
    'Personal': 'fa-user',
    'Research': 'fa-flask',
    'Education': 'fa-graduation-cap',
    'Development': 'fa-laptop-code',
    'Design': 'fa-paint-brush',
    'Writing': 'fa-pen',
    'Research & Analysis': 'fa-chart-bar'
  };

  // Get icon for category or default
  const getCategoryIcon = (name) => {
    return categoryIcons[name] || 'fa-folder';
  };

  // Handle creating a new category
  const handleCreateCategory = () => {
    if (!newCategoryInput.trim()) return;

    // Check if category already exists
    const exists = availableCategories.some((category) =>
    category.name.toLowerCase() === newCategoryInput.trim().toLowerCase()
    );

    if (exists) {
      // Find and select the existing category
      const existingCategory = availableCategories.find((category) =>
      category.name.toLowerCase() === newCategoryInput.trim().toLowerCase()
      );
      onCategorySelect(existingCategory);
    } else if (onCategoryCreate) {
      // Create a new category
      onCategoryCreate({
        name: newCategoryInput.trim(),
        color: selectedColor
      });
    }

    // Reset input
    setNewCategoryInput('');
    setShowCreateField(false);
    setColorPickerOpen(false);
  };

  return (
    <div className="category-selector" data-id="pfyxkpyxn" data-path="components/CategorySelector.js">
      {/* Selected Category */}
      <div className="mb-4" data-id="jvzk4mf7s" data-path="components/CategorySelector.js">
        <div className="text-sm text-gray-400 mb-2" data-id="q2r53qsst" data-path="components/CategorySelector.js">Selected Category</div>
        {selectedCategory ?
        <div className="bg-darklight rounded-lg p-3 flex items-center justify-between" data-id="icem2ratm" data-path="components/CategorySelector.js">
            <div className="flex items-center" data-id="fx9rtpbs0" data-path="components/CategorySelector.js">
              <div className="w-8 h-8 rounded-full flex items-center justify-center mr-3 bg-black bg-opacity-30" data-id="p3kvft7lg" data-path="components/CategorySelector.js">
                <i className={`fas ${getCategoryIcon(selectedCategory)}`} data-id="o8watpwk2" data-path="components/CategorySelector.js"></i>
              </div>
              <div data-id="r89w2iz0n" data-path="components/CategorySelector.js">
                <div className="font-medium" data-id="a9ok7c3yc" data-path="components/CategorySelector.js">{selectedCategory}</div>
              </div>
            </div>
            <button
            className="text-gray-400 hover:text-white"
            onClick={() => onCategorySelect(null)} data-id="zhmj8en8t" data-path="components/CategorySelector.js">

              <i className="fas fa-times" data-id="bxnoman43" data-path="components/CategorySelector.js"></i>
            </button>
          </div> :

        <div className="text-gray-500 italic text-sm" data-id="w27dsk5i4" data-path="components/CategorySelector.js">No category selected</div>
        }
      </div>
      
      {/* Create New Category Input */}
      {showCreateField ?
      <div className="mb-4 bg-darklight p-3 rounded-lg" data-id="zp42cemql" data-path="components/CategorySelector.js">
          <div className="mb-3" data-id="vyyas0rp8" data-path="components/CategorySelector.js">
            <label className="block text-sm text-gray-400 mb-1" data-id="jrotlzq0z" data-path="components/CategorySelector.js">Category Name</label>
            <input
            type="text"
            className="auth-input"
            placeholder="Enter new category name"
            value={newCategoryInput}
            onChange={(e) => setNewCategoryInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleCreateCategory();
              }
            }} data-id="4kb71g96b" data-path="components/CategorySelector.js" />

          </div>
          
          <div className="mb-3" data-id="phlxwyzt1" data-path="components/CategorySelector.js">
            <label className="block text-sm text-gray-400 mb-1" data-id="qpiopmad3" data-path="components/CategorySelector.js">Category Color</label>
            <div
            className="flex items-center cursor-pointer p-2 bg-gray-800 rounded"
            onClick={() => setColorPickerOpen(!colorPickerOpen)} data-id="kzs22fik5" data-path="components/CategorySelector.js">

              <div
              className="w-6 h-6 rounded-full mr-2"
              style={{ backgroundColor: selectedColor }} data-id="ecg05vfkg" data-path="components/CategorySelector.js">
            </div>
              <span data-id="lnwkhogky" data-path="components/CategorySelector.js">{selectedColor}</span>
              <i className={`fas fa-chevron-${colorPickerOpen ? 'up' : 'down'} ml-auto`} data-id="udd1fl37q" data-path="components/CategorySelector.js"></i>
            </div>
            
            {colorPickerOpen &&
          <div className="mt-2 grid grid-cols-4 gap-2" data-id="ymbqxqqsl" data-path="components/CategorySelector.js">
                {categoryColors.map((color, index) =>
            <div
              key={index}
              className={`w-full p-1 rounded cursor-pointer ${selectedColor === color ? 'ring-2 ring-white' : ''}`}
              onClick={() => setSelectedColor(color)} data-id="rpywjevyb" data-path="components/CategorySelector.js">

                    <div
                className="w-full h-8 rounded"
                style={{ backgroundColor: color }} data-id="ctlnf0ug6" data-path="components/CategorySelector.js">
              </div>
                  </div>
            )}
              </div>
          }
          </div>
          
          <div className="flex gap-2" data-id="3zzrkxf25" data-path="components/CategorySelector.js">
            <Button
            variant="outline"
            onClick={() => setShowCreateField(false)}>

              Cancel
            </Button>
            <Button
            onClick={handleCreateCategory}
            disabled={!newCategoryInput.trim()}>

              Create Category
            </Button>
          </div>
        </div> :

      <div className="mb-4" data-id="moeljjl79" data-path="components/CategorySelector.js">
          <Button
          variant="outline"
          size="sm"
          fullWidth
          onClick={() => setShowCreateField(true)}
          icon={<i className="fas fa-plus" data-id="hpgzd03qg" data-path="components/CategorySelector.js"></i>}>

            Create New Category
          </Button>
        </div>
      }
      
      {/* Available Categories */}
      <div data-id="ly02ma2up" data-path="components/CategorySelector.js">
        <div className="text-sm text-gray-400 mb-2" data-id="u5d2qzim9" data-path="components/CategorySelector.js">Available Categories</div>
        <div className="grid grid-cols-1 gap-2" data-id="hudnmi84b" data-path="components/CategorySelector.js">
          {availableCategories.map((category, index) =>
          <div
            key={index}
            className={`
                p-3 rounded-lg cursor-pointer transition-all
                flex items-center justify-between
                ${selectedCategory === category.name ?
            'bg-secondary text-white' :
            'bg-darklight hover:bg-gray-700 text-gray-300'}
              `}
            onClick={() => onCategorySelect(category)} data-id="q27if4j5z" data-path="components/CategorySelector.js">

              <div className="flex items-center" data-id="kc9k8oyle" data-path="components/CategorySelector.js">
                <div
                className={`
                    w-8 h-8 rounded-full flex items-center justify-center mr-3
                    ${selectedCategory === category.name ? 'bg-white bg-opacity-20' : 'bg-black bg-opacity-30'}
                  `}
                style={category.color ? { backgroundColor: `${category.color}30` } : {}} data-id="sesu8h9ic" data-path="components/CategorySelector.js">

                  <i className={`fas ${getCategoryIcon(category.name)}`} data-id="udhdoo2l2" data-path="components/CategorySelector.js"></i>
                </div>
                <div data-id="6a1knicfi" data-path="components/CategorySelector.js">
                  <div className="font-medium" data-id="811ogjgk6" data-path="components/CategorySelector.js">{category.name}</div>
                  <div className="text-xs opacity-80" data-id="90p5ad65w" data-path="components/CategorySelector.js">
                    {category.count} {category.count === 1 ? 'prompt' : 'prompts'}
                  </div>
                </div>
              </div>
              <i className="fas fa-chevron-right" data-id="nefez4kte" data-path="components/CategorySelector.js"></i>
            </div>
          )}
        </div>
      </div>
    </div>);

};