// Component for entering and saving new prompts

const PromptInput = ({ existingPrompt = null }) => {
  const { useState, useEffect } = React;
  const { addPrompt, updatePrompt, categories, tags } = usePrompts();
  const navigate = ReactRouterDOM.useNavigate();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedTags, setSelectedTags] = useState([]);
  const [showTagsSelector, setShowTagsSelector] = useState(false);
  const [showCategorySelector, setShowCategorySelector] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Load existing prompt data if editing
  useEffect(() => {
    if (existingPrompt) {
      setTitle(existingPrompt.title || '');
      setContent(existingPrompt.content || '');
      setSelectedCategory(existingPrompt.category || null);
      setSelectedTags(existingPrompt.tags || []);
      setIsEditing(true);
    }
  }, [existingPrompt]);

  // Handle category selection
  const handleCategorySelect = (category) => {
    setSelectedCategory(category.name);
    setShowCategorySelector(false);
  };

  // Handle tag selection/deselection
  const handleTagSelect = (tag) => {
    if (selectedTags.includes(tag.name)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag.name));
    } else {
      setSelectedTags([...selectedTags, tag.name]);
    }
  };

  // Analyze content to suggest tags and category
  const analyzeContent = async () => {
    if (!content.trim()) return;

    try {
      setIsAnalyzing(true);
      setError('');

      // In a real app this would call an AI service
      // For now, simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Auto-generate title if not set
      if (!title) {
        // Generate a title from the first few words
        const newTitle = content.split(' ').slice(0, 5).join(' ') + (
        content.split(' ').length > 5 ? '...' : '');
        setTitle(newTitle);
      }

      // Suggest random tags if none selected
      if (selectedTags.length === 0) {
        const allPossibleTags = [
        'creative', 'technical', 'business', 'marketing',
        'writing', 'coding', 'data', 'design', 'analysis',
        'research', 'storytelling', 'productivity'];


        // Extract some random tags based on content length
        const numTags = Math.min(3, Math.floor(content.length / 50) + 1);
        const suggestedTags = [];

        for (let i = 0; i < numTags; i++) {
          const randomTag = allPossibleTags[Math.floor(Math.random() * allPossibleTags.length)];
          if (!suggestedTags.includes(randomTag)) {
            suggestedTags.push(randomTag);
          }
        }

        setSelectedTags(suggestedTags);
      }

      // Suggest category if none selected
      if (!selectedCategory) {
        const allCategories = [
        'General', 'Creative Writing', 'Technical', 'Business',
        'Marketing', 'Personal', 'Research', 'Education'];


        const category = allCategories[Math.floor(Math.random() * allCategories.length)];
        setSelectedCategory(category);
      }

    } catch (error) {
      console.error('Error analyzing content:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle saving prompt
  const handleSavePrompt = async () => {
    // Validate input
    if (!content.trim()) {
      setError('Please enter a prompt');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Analyze content if not already done
      if (!selectedCategory || selectedTags.length === 0) {
        await analyzeContent();
      }

      const promptData = {
        title: title || 'New Prompt',
        content,
        category: selectedCategory || 'General',
        tags: selectedTags
      };

      if (isEditing && existingPrompt) {
        // Update existing prompt
        await updatePrompt(existingPrompt.id, promptData);
        setSuccess('Prompt updated successfully!');
      } else {
        // Add new prompt
        await addPrompt(content);
        setSuccess('Prompt saved successfully!');
        // Clear input after saving
        setContent('');
        setTitle('');
        setSelectedCategory(null);
        setSelectedTags([]);
      }

      // Auto-hide success message after 3 seconds
      setTimeout(() => {
        setSuccess('');
      }, 3000);
    } catch (error) {
      setError(`Failed to save prompt: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle cancel editing
  const handleCancel = () => {
    if (isEditing) {
      navigate(-1); // Go back to previous page
    } else {
      // Just clear the input
      setContent('');
      setTitle('');
      setSelectedCategory(null);
      setSelectedTags([]);
    }
  };

  return (
    <div className="prompt-input-container" data-id="vd5i8ca16" data-path="components/PromptInput.js">
      {/* Title input */}
      <div className="mb-4" data-id="6ljgzcspg" data-path="components/PromptInput.js">
        <label className="block text-gray-300 mb-1" htmlFor="prompt-title" data-id="vmaow78ui" data-path="components/PromptInput.js">Title (Optional)</label>
        <input
          id="prompt-title"
          className="auth-input"
          placeholder="Enter a title for your prompt"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          disabled={loading} data-id="2vy3ihcrs" data-path="components/PromptInput.js" />

      </div>
      
      {/* Content textarea */}
      <div className="mb-4" data-id="vpiteuu1u" data-path="components/PromptInput.js">
        <label className="block text-gray-300 mb-1" htmlFor="prompt-content" data-id="69l446hdn" data-path="components/PromptInput.js">Prompt Content</label>
        <textarea
          id="prompt-content"
          className="prompt-textarea"
          placeholder="Enter your prompt here..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={loading}
          rows={8} data-id="hdktyvb65" data-path="components/PromptInput.js" />

      </div>
      
      {/* Category selector */}
      <div className="mb-4" data-id="hvyd490gr" data-path="components/PromptInput.js">
        <div className="flex justify-between items-center mb-1" data-id="o4983aqt4" data-path="components/PromptInput.js">
          <label className="block text-gray-300" data-id="3cz86uqda" data-path="components/PromptInput.js">Category</label>
          <button
            className="text-xs text-primary hover:underline"
            onClick={() => setShowCategorySelector(!showCategorySelector)} data-id="cw78x0x8a" data-path="components/PromptInput.js">

            {showCategorySelector ? 'Hide Categories' : 'Select Category'}
          </button>
        </div>
        
        {selectedCategory ?
        <div className="flex items-center bg-darklight rounded-lg p-2 mb-2" data-id="ueffh1hjb" data-path="components/PromptInput.js">
            <div className="bg-primary bg-opacity-20 text-primary rounded-full p-1 mr-2" data-id="qeephdzzf" data-path="components/PromptInput.js">
              <i className="fas fa-folder" data-id="el3x6468g" data-path="components/PromptInput.js"></i>
            </div>
            <span data-id="vmi412r26" data-path="components/PromptInput.js">{selectedCategory}</span>
            <button
            className="ml-auto text-gray-400 hover:text-white"
            onClick={() => setSelectedCategory(null)} data-id="u2llj4vq9" data-path="components/PromptInput.js">

              <i className="fas fa-times" data-id="sa2jc801j" data-path="components/PromptInput.js"></i>
            </button>
          </div> :

        <div className="text-gray-400 text-sm mb-2" data-id="ycylol5fp" data-path="components/PromptInput.js">No category selected</div>
        }
        
        {showCategorySelector &&
        <div className="bg-darklight rounded-lg p-3 mb-3" data-id="sqe7zqx25" data-path="components/PromptInput.js">
            <CategoryList
            categories={categories}
            onCategorySelect={handleCategorySelect}
            activeCategory={selectedCategory} />

          </div>
        }
      </div>
      
      {/* Tags selector */}
      <div className="mb-4" data-id="cwrunffz8" data-path="components/PromptInput.js">
        <div className="flex justify-between items-center mb-1" data-id="lg91u0cwd" data-path="components/PromptInput.js">
          <label className="block text-gray-300" data-id="y3ajt2jp3" data-path="components/PromptInput.js">Tags</label>
          <button
            className="text-xs text-primary hover:underline"
            onClick={() => setShowTagsSelector(!showTagsSelector)} data-id="at5vhb139" data-path="components/PromptInput.js">

            {showTagsSelector ? 'Hide Tags' : 'Select Tags'}
          </button>
        </div>
        
        {selectedTags.length > 0 ?
        <div className="flex flex-wrap gap-2 mb-2" data-id="13f6625fz" data-path="components/PromptInput.js">
            {selectedTags.map((tag, index) =>
          <div key={index} className="bg-primary bg-opacity-20 text-primary rounded-full px-3 py-1 text-sm flex items-center" data-id="het72cyje" data-path="components/PromptInput.js">
                <i className="fas fa-tag mr-1" data-id="ymcqxt4mv" data-path="components/PromptInput.js"></i>
                <span data-id="4avu43tph" data-path="components/PromptInput.js">{tag}</span>
                <button
              className="ml-2 text-primary-light hover:text-primary-dark"
              onClick={() => setSelectedTags(selectedTags.filter((t) => t !== tag))} data-id="g3nwtye52" data-path="components/PromptInput.js">

                  <i className="fas fa-times" data-id="qhu0t4hvm" data-path="components/PromptInput.js"></i>
                </button>
              </div>
          )}
          </div> :

        <div className="text-gray-400 text-sm mb-2" data-id="o4zdamzog" data-path="components/PromptInput.js">No tags selected</div>
        }
        
        {showTagsSelector &&
        <div className="bg-darklight rounded-lg p-3 mb-3" data-id="373a8eaoc" data-path="components/PromptInput.js">
            <TagCloud
            tags={tags}
            onTagSelect={(tag) => handleTagSelect(tag)}
            maxSize={12}
            minSize={8} />

          </div>
        }
      </div>
      
      {/* Error and success messages */}
      {error &&
      <div className="text-error text-sm mb-4" data-id="w9ofizy9v" data-path="components/PromptInput.js">
          <i className="fas fa-exclamation-circle mr-1" data-id="nyge58imh" data-path="components/PromptInput.js"></i> {error}
        </div>
      }
      
      {success &&
      <div className="text-success text-sm mb-4" data-id="frh3qs1fd" data-path="components/PromptInput.js">
          <i className="fas fa-check-circle mr-1" data-id="67gr8ktti" data-path="components/PromptInput.js"></i> {success}
        </div>
      }
      
      {/* Action buttons */}
      <div className="prompt-actions" data-id="co2yo8kmm" data-path="components/PromptInput.js">
        <Button
          variant="outline"
          onClick={() => navigate(-1)}
          icon={<i className="fas fa-arrow-left" data-id="86577vkrr" data-path="components/PromptInput.js"></i>}>

          Back
        </Button>
        
        {content &&
        <Button
          variant="outline"
          onClick={handleCancel}
          disabled={loading}>

            {isEditing ? 'Cancel' : 'Clear'}
          </Button>
        }
        
        <Button
          onClick={analyzeContent}
          disabled={loading || isAnalyzing || !content.trim()}
          loading={isAnalyzing}
          icon={<i className="fas fa-magic" data-id="kxu6u27f7" data-path="components/PromptInput.js"></i>}>

          Analyze
        </Button>
        
        <Button
          onClick={handleSavePrompt}
          loading={loading}
          disabled={loading || !content.trim()}
          icon={<i className={`fas ${isEditing ? 'fa-save' : 'fa-plus'}`} data-id="05s0r6xms" data-path="components/PromptInput.js"></i>}>

          {isEditing ? 'Update Prompt' : 'Save Prompt'}
        </Button>
      </div>
    </div>);

};