// Component for displaying a list of tags

const TagList = ({ tags = [], onTagSelect, activeTag = null }) => {
  const navigate = ReactRouterDOM.useNavigate();

  // Handle tag click
  const handleTagClick = (tag) => {
    if (onTagSelect) {
      onTagSelect(tag);
    } else {
      navigate(`/tags/${tag.name}`);
    }
  };

  // Sort tags by count (descending)
  const sortedTags = [...tags].sort((a, b) => b.count - a.count);

  // Empty state when no tags
  if (tags.length === 0) {
    return (
      <div className="p-4 text-center text-gray-400" data-id="ea9gw5p4p" data-path="components/TagList.js">
        <i className="fas fa-tag mb-2 text-2xl" data-id="ridpr96v8" data-path="components/TagList.js"></i>
        <p data-id="kkl46dx5p" data-path="components/TagList.js">No tags found</p>
      </div>);

  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2" data-id="a9j5kpdgy" data-path="components/TagList.js">
      {sortedTags.map((tag, index) =>
      <div
        key={index}
        className={`
            px-4 py-3 rounded-lg text-sm cursor-pointer transition-all
            flex items-center justify-between
            ${activeTag === tag.name ?
        'bg-primary text-white' :
        'bg-darklight hover:bg-gray-700 text-gray-300'}
          `
        }
        onClick={() => handleTagClick(tag)} data-id="bdx3wdgys" data-path="components/TagList.js">

          <div className="flex items-center" data-id="zuy6744k7" data-path="components/TagList.js">
            <i className="fas fa-tag mr-2" data-id="1cxb8u657" data-path="components/TagList.js"></i>
            <span data-id="66bb4vy6t" data-path="components/TagList.js">{tag.name}</span>
          </div>
          <div className="bg-black bg-opacity-30 px-2 py-0.5 rounded-full text-xs" data-id="6on9yy1uj" data-path="components/TagList.js">
            {tag.count}
          </div>
        </div>
      )}
    </div>);

};

// TagCloud component for displaying tag cloud with varying sizes
const TagCloud = ({ tags = [], onTagSelect, maxSize = 10, minSize = 5 }) => {
  // Find the max count to scale tag sizes
  const maxCount = Math.max(...tags.map((tag) => tag.count), 1);

  // Calculate tag size based on count
  const getTagSize = (count) => {
    const size = minSize + count / maxCount * (maxSize - minSize);
    return Math.max(minSize, Math.min(maxSize, size));
  };

  // Sort tags alphabetically for cloud
  const sortedTags = [...tags].sort((a, b) => a.name.localeCompare(b.name));

  // Empty state when no tags
  if (tags.length === 0) {
    return (
      <div className="p-4 text-center text-gray-400" data-id="p635lhc7x" data-path="components/TagList.js">
        <p data-id="n7njxyydp" data-path="components/TagList.js">No tags found</p>
      </div>);

  }

  return (
    <div className="flex flex-wrap gap-2 p-4" data-id="fpkmt3ndu" data-path="components/TagList.js">
      {sortedTags.map((tag, index) => {
        const size = getTagSize(tag.count);
        return (
          <div
            key={index}
            className={`
              px-3 py-1 rounded-full cursor-pointer transition-all
              bg-opacity-20 border
              hover:bg-opacity-30
            `}
            style={{
              backgroundColor: `${stringToColor(tag.name)}20`,
              borderColor: `${stringToColor(tag.name)}40`,
              color: stringToColor(tag.name),
              fontSize: `${size / 10}rem`
            }}
            onClick={() => onTagSelect(tag)} data-id="fgoafrluz" data-path="components/TagList.js">

            {tag.name}
          </div>);

      })}
    </div>);

};