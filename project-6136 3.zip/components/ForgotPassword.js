// Forgot Password component

const ForgotPassword = ({ onCancel }) => {
  const { useState } = React;

  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate email
    if (!email) {
      setError('Please enter your email address');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Call API to send reset password email
      const response = await window.ezsite.apis.sendResetPwdEmail({
        email
      });

      if (response.error) {
        throw new Error(response.error);
      }

      // Show success message
      setSuccess(true);

    } catch (error) {
      setError(error.message || 'Failed to send reset email');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="auth-form-container" data-id="oqo1227oj" data-path="components/ForgotPassword.js">
        <div className="text-center mb-6" data-id="faa6yy8pr" data-path="components/ForgotPassword.js">
          <i className="fas fa-check-circle text-green-400 text-5xl mb-4" data-id="yraca6wbn" data-path="components/ForgotPassword.js"></i>
          <h2 className="text-xl font-semibold mb-2" data-id="qjtbkl6oc" data-path="components/ForgotPassword.js">Reset Email Sent</h2>
          <p className="text-gray-300" data-id="ux18o04oj" data-path="components/ForgotPassword.js">
            Check your email for a link to reset your password. If it doesn't appear within a few minutes, check your spam folder.
          </p>
        </div>
        
        <Button
          onClick={onCancel}
          fullWidth>
          Back to Login
        </Button>
      </div>);

  }

  return (
    <div className="auth-form-container" data-id="xrk9jgx1t" data-path="components/ForgotPassword.js">
      <h2 className="text-xl font-semibold mb-4" data-id="2uzil63up" data-path="components/ForgotPassword.js">Reset Your Password</h2>
      <p className="text-gray-300 mb-6" data-id="ao558zui0" data-path="components/ForgotPassword.js">
        Enter your email address and we'll send you a link to reset your password.
      </p>
      
      <form onSubmit={handleSubmit} data-id="0lazew8vr" data-path="components/ForgotPassword.js">
        <div className="form-group" data-id="pkksfgqn3" data-path="components/ForgotPassword.js">
          <label className="block text-gray-300 mb-1" htmlFor="reset-email" data-id="xzxgavoz5" data-path="components/ForgotPassword.js">Email</label>
          <input
            id="reset-email"
            type="email"
            className="auth-input"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={loading} data-id="dgowpjjze" data-path="components/ForgotPassword.js" />

        </div>
        
        {error && <div className="auth-error mb-4" data-id="16zsrxikk" data-path="components/ForgotPassword.js">{error}</div>}
        
        <div className="flex gap-3 mt-6" data-id="wq7p6f0sf" data-path="components/ForgotPassword.js">
          <Button
            type="submit"
            fullWidth
            loading={loading}
            disabled={loading}>
            Send Reset Link
          </Button>
          
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            fullWidth
            disabled={loading}>
            Cancel
          </Button>
        </div>
      </form>
    </div>);

};