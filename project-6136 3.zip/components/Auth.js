// Auth components for login and registration

const Login = ({ onSwitchToRegister, onForgotPassword }) => {
  const { useState } = React;
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate inputs
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }

    try {
      setError('');
      setLoading(true);
      await login(email, password);
      // Successful login is handled by the auth context, which will redirect the user
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-form-container" data-id="7sp7pzdsa" data-path="components/Auth.js">
      <form onSubmit={handleSubmit} data-id="12xqy7xj9" data-path="components/Auth.js">
        <div className="form-group" data-id="pw5m9knp3" data-path="components/Auth.js">
          <label className="block text-gray-300 mb-1" htmlFor="email" data-id="yoqk67t96" data-path="components/Auth.js">Email</label>
          <input
            id="email"
            type="email"
            className="auth-input"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={loading} data-id="2moq2tnhm" data-path="components/Auth.js" />

        </div>
        
        <div className="form-group" data-id="763on5vex" data-path="components/Auth.js">
          <div className="flex justify-between mb-1" data-id="lgj4z4n8p" data-path="components/Auth.js">
            <label className="text-gray-300" htmlFor="password" data-id="3xqiioonl" data-path="components/Auth.js">Password</label>
            <span className="auth-link text-sm cursor-pointer" onClick={onForgotPassword} data-id="v6laebhzp" data-path="components/Auth.js">Forgot Password?</span>
          </div>
          <input
            id="password"
            type="password"
            className="auth-input"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={loading} data-id="6jtf2z16v" data-path="components/Auth.js" />

        </div>
        
        {error && <div className="auth-error mb-4" data-id="qb2k0m10x" data-path="components/Auth.js">{error}</div>}
        
        <Button
          type="submit"
          fullWidth
          loading={loading}
          disabled={loading}>

          Log In
        </Button>
      </form>
      
      <div className="auth-footer" data-id="6106yab2n" data-path="components/Auth.js">
        <p data-id="8apmd9zyb" data-path="components/Auth.js">
          Don't have an account?{' '}
          <span className="auth-link" onClick={onSwitchToRegister} data-id="u000f57kn" data-path="components/Auth.js">
            Register now
          </span>
        </p>
      </div>
    </div>);

};

const Register = ({ onSwitchToLogin }) => {
  const { useState } = React;
  const { register } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate inputs
    if (!name || !email || !password || !confirmPassword) {
      setError('Please fill in all fields');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    try {
      setError('');
      setLoading(true);
      await register(email, password, name);
      // Successful registration is handled by the auth context, which will redirect the user
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-form-container" data-id="eji3q574s" data-path="components/Auth.js">
      <form onSubmit={handleSubmit} data-id="5aj6fbj7j" data-path="components/Auth.js">
        <div className="form-group" data-id="ilvrc9xhs" data-path="components/Auth.js">
          <label className="block text-gray-300 mb-1" htmlFor="name" data-id="bbkb4x6o5" data-path="components/Auth.js">Full Name</label>
          <input
            id="name"
            type="text"
            className="auth-input"
            placeholder="Enter your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            disabled={loading} data-id="o5iqi2llb" data-path="components/Auth.js" />

        </div>
        
        <div className="form-group" data-id="w1fk826vg" data-path="components/Auth.js">
          <label className="block text-gray-300 mb-1" htmlFor="register-email" data-id="z6j99p0u0" data-path="components/Auth.js">Email</label>
          <input
            id="register-email"
            type="email"
            className="auth-input"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={loading} data-id="jojvmhxdg" data-path="components/Auth.js" />

        </div>
        
        <div className="form-group" data-id="qvfmor1ie" data-path="components/Auth.js">
          <label className="block text-gray-300 mb-1" htmlFor="register-password" data-id="aanpi0m7e" data-path="components/Auth.js">Password</label>
          <input
            id="register-password"
            type="password"
            className="auth-input"
            placeholder="Create a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={loading} data-id="w1f8lwylr" data-path="components/Auth.js" />

        </div>
        
        <div className="form-group" data-id="f2j0zb2n3" data-path="components/Auth.js">
          <label className="block text-gray-300 mb-1" htmlFor="confirm-password" data-id="nah322lnk" data-path="components/Auth.js">Confirm Password</label>
          <input
            id="confirm-password"
            type="password"
            className="auth-input"
            placeholder="Confirm your password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            disabled={loading} data-id="fhowbhlcx" data-path="components/Auth.js" />

        </div>
        
        {error && <div className="auth-error mb-4" data-id="b3opjbzyp" data-path="components/Auth.js">{error}</div>}
        
        <Button
          type="submit"
          fullWidth
          loading={loading}
          disabled={loading}>

          Register
        </Button>
      </form>
      
      <div className="auth-footer" data-id="cao6k4vup" data-path="components/Auth.js">
        <p data-id="kgyq5cch5" data-path="components/Auth.js">
          Already have an account?{' '}
          <span className="auth-link" onClick={onSwitchToLogin} data-id="pzmlqd8cs" data-path="components/Auth.js">
            Log in
          </span>
        </p>
      </div>
    </div>);

};

// Main Auth component that toggles between Login and Register
const Auth = () => {
  const { useState } = React;
  const [activeTab, setActiveTab] = useState('login');
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  return (
    <div className="auth-card" data-id="0k9c1rfp6" data-path="components/Auth.js">
      <div className="auth-logo" data-id="42hwv4qul" data-path="components/Auth.js">
        <h1 data-id="hhguznkaj" data-path="components/Auth.js">PromptMaster</h1>
      </div>
      
      {!showForgotPassword &&
      <div className="auth-tabs" data-id="ftahrgfgl" data-path="components/Auth.js">
          <div
          className={`auth-tab ${activeTab === 'login' ? 'active' : ''}`}
          onClick={() => setActiveTab('login')} data-id="l5m7zxmzv" data-path="components/Auth.js">

            Login
          </div>
          <div
          className={`auth-tab ${activeTab === 'register' ? 'active' : ''}`}
          onClick={() => setActiveTab('register')} data-id="wyleador2" data-path="components/Auth.js">

            Register
          </div>
        </div>
      }
      
      {showForgotPassword ?
      <ForgotPassword onCancel={() => setShowForgotPassword(false)} /> :
      activeTab === 'login' ?
      <Login
        onSwitchToRegister={() => setActiveTab('register')}
        onForgotPassword={() => setShowForgotPassword(true)} /> :


      <Register onSwitchToLogin={() => setActiveTab('login')} />
      }
    </div>);

};