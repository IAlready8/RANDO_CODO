// Sidebar navigation component

const Sidebar = ({ isOpen, toggleSidebar }) => {
  const { currentUser, logout } = useAuth();
  const location = ReactRouterDOM.useLocation();
  const navigate = ReactRouterDOM.useNavigate();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Navigation items
  const navItems = [
  {
    icon: <i className="fas fa-home" data-id="vj2lozgjy" data-path="components/Sidebar.js"></i>,
    label: 'Dashboard',
    path: '/'
  },
  {
    icon: <i className="fas fa-chart-line" data-id="9vdy9bx51" data-path="components/Sidebar.js"></i>,
    label: 'Analytics',
    path: '/analytics'
  },
  {
    icon: <i className="fas fa-folder" data-id="dhppz7eq6" data-path="components/Sidebar.js"></i>,
    label: 'Categories',
    path: '/categories'
  },
  {
    icon: <i className="fas fa-tag" data-id="xv4hesq1f" data-path="components/Sidebar.js"></i>,
    label: 'Tags',
    path: '/tags'
  },
  {
    icon: <i className="fas fa-history" data-id="egbxc9m4m" data-path="components/Sidebar.js"></i>,
    label: 'History',
    path: '/history'
  },
  {
    icon: <i className="fas fa-cog" data-id="r6f4gap0v" data-path="components/Sidebar.js"></i>,
    label: 'Settings',
    path: '/settings'
  }];


  // Check if path is active
  const isActivePath = (path) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/auth');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <>
      <aside className={`sidebar ${isOpen ? '' : 'sidebar-collapsed'}`} data-id="71d5o259t" data-path="components/Sidebar.js">
        <div className="sidebar-header" data-id="tjnyte5a9" data-path="components/Sidebar.js">
          <div className="sidebar-logo" data-id="v1661quyx" data-path="components/Sidebar.js">PromptMaster</div>
          <button className="sidebar-toggle" onClick={toggleSidebar} data-id="udlkpnxe8" data-path="components/Sidebar.js">
            <i className="fas fa-bars" data-id="og9hfs3au" data-path="components/Sidebar.js"></i>
          </button>
        </div>
        
        <nav className="sidebar-nav" data-id="k7qtk7230" data-path="components/Sidebar.js">
          {navItems.map((item, index) =>
          <div
            key={index}
            className={`sidebar-item ${isActivePath(item.path) ? 'active' : ''}`}
            onClick={() => {
              navigate(item.path);
              // Close sidebar on mobile after navigation
              if (window.innerWidth < 768) {
                toggleSidebar();
              }
            }} data-id="bg6zt0sxc" data-path="components/Sidebar.js">
              <span className="w-5" data-id="1o1njcrfu" data-path="components/Sidebar.js">{item.icon}</span>
              <span data-id="wcyp0ac0l" data-path="components/Sidebar.js">{item.label}</span>
            </div>
          )}
        </nav>
        
        <div className="mt-8 px-4" data-id="olyk323os" data-path="components/Sidebar.js">
          <Button
            fullWidth
            icon={<i className="fas fa-plus" data-id="2n3safef1" data-path="components/Sidebar.js"></i>}
            onClick={() => navigate('/new-prompt')}>
            New Prompt
          </Button>
        </div>
        
        <div className="sidebar-footer" data-id="hyeeeveub" data-path="components/Sidebar.js">
          <div className="sidebar-user" data-id="fx46k8rd7" data-path="components/Sidebar.js">
            <div className="sidebar-user-avatar" data-id="4sm55fvus" data-path="components/Sidebar.js">
              {getInitials(currentUser?.name || 'User')}
            </div>
            <div className="sidebar-user-info" data-id="dcsq7g4w6" data-path="components/Sidebar.js">
              <div className="sidebar-user-name" data-id="9s5nlpd7p" data-path="components/Sidebar.js">{currentUser?.name || 'User'}</div>
              <div className="sidebar-user-email" data-id="ty0iiy06d" data-path="components/Sidebar.js">{currentUser?.email || 'user@example.com'}</div>
            </div>
          </div>
          
          <div className="mt-4 px-4" data-id="ger53nc2k" data-path="components/Sidebar.js">
            <Button
              fullWidth
              variant="outline"
              size="sm"
              icon={<i className="fas fa-sign-out-alt" data-id="8tuk4rta8" data-path="components/Sidebar.js"></i>}
              onClick={() => setShowLogoutConfirm(true)}>
              Logout
            </Button>
          </div>
        </div>
      </aside>
      
      {/* Logout Confirmation Modal */}
      <ConfirmModal
        isOpen={showLogoutConfirm}
        onClose={() => setShowLogoutConfirm(false)}
        onConfirm={handleLogout}
        title="Logout"
        message="Are you sure you want to logout? Any unsaved changes will be lost."
        confirmText="Logout"
        cancelText="Cancel"
        variant="primary" />

    </>);

};