// Component for displaying a list of categories

const CategoryList = ({ categories = [], onCategorySelect, activeCategory = null }) => {
  const navigate = ReactRouterDOM.useNavigate();

  // Handle category click
  const handleCategoryClick = (category) => {
    if (onCategorySelect) {
      onCategorySelect(category);
    } else {
      navigate(`/categories/${category.name}`);
    }
  };

  // Sort categories by count (descending)
  const sortedCategories = [...categories].sort((a, b) => b.count - a.count);

  // Category icons mapping
  const categoryIcons = {
    'General': 'fa-cube',
    'Creative Writing': 'fa-feather',
    'Technical': 'fa-code',
    'Business': 'fa-briefcase',
    'Marketing': 'fa-bullhorn',
    'Personal': 'fa-user',
    'Research': 'fa-flask',
    'Education': 'fa-graduation-cap',
    'Development': 'fa-laptop-code',
    'Design': 'fa-paint-brush',
    'Writing': 'fa-pen',
    'Research & Analysis': 'fa-chart-bar'
  };

  // Get icon for category or default
  const getCategoryIcon = (name) => {
    return categoryIcons[name] || 'fa-folder';
  };

  // Empty state when no categories
  if (categories.length === 0) {
    return (
      <div className="p-4 text-center text-gray-400" data-id="dyipmfo6w" data-path="components/CategoryList.js">
        <i className="fas fa-folder mb-2 text-2xl" data-id="0jyme04nb" data-path="components/CategoryList.js"></i>
        <p data-id="ivneuen6n" data-path="components/CategoryList.js">No categories found</p>
      </div>);

  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3" data-id="s73z9y05l" data-path="components/CategoryList.js">
      {sortedCategories.map((category, index) =>
      <div
        key={index}
        className={`
            p-4 rounded-lg cursor-pointer transition-all
            flex items-center justify-between
            ${activeCategory === category.name ?
        'bg-secondary text-white' :
        'bg-darklight hover:bg-gray-700 text-gray-300'}
          `
        }
        onClick={() => handleCategoryClick(category)} data-id="wpn64i3iz" data-path="components/CategoryList.js">

          <div className="flex items-center" data-id="x0jga511i" data-path="components/CategoryList.js">
            <div className={`
              w-10 h-10 rounded-full flex items-center justify-center mr-3
              ${activeCategory === category.name ? 'bg-white bg-opacity-20' : 'bg-black bg-opacity-30'}
            `} data-id="e45u2ozeq" data-path="components/CategoryList.js">
              <i className={`fas ${getCategoryIcon(category.name)}`} data-id="hakn82m9j" data-path="components/CategoryList.js"></i>
            </div>
            <div data-id="iyjjcjrae" data-path="components/CategoryList.js">
              <div className="font-medium" data-id="32oud04j2" data-path="components/CategoryList.js">{category.name}</div>
              <div className="text-xs opacity-80" data-id="87wn2fmvj" data-path="components/CategoryList.js">
                {category.count} {category.count === 1 ? 'prompt' : 'prompts'}
              </div>
            </div>
          </div>
          <i className="fas fa-chevron-right" data-id="1krflknkv" data-path="components/CategoryList.js"></i>
        </div>
      )}
    </div>);

};