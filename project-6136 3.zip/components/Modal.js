// Modal component for dialogs and forms

const Modal = ({
  isOpen,
  onClose,
  title,
  children,
  size = 'md',
  footer = null
}) => {
  const { useEffect } = React;

  // Close modal when Escape key is pressed
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleEscape);

    // Prevent body scrolling when modal is open
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      window.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Handle modal sizing
  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-full mx-4'
  };

  // Prevent click on modal content from closing the modal
  const handleModalClick = (e) => {
    e.stopPropagation();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-70 animate-fade-in"
      onClick={onClose} data-id="l4et290jm" data-path="components/Modal.js">

      <div
        className={`w-full ${sizeClasses[size]} bg-darklight rounded-xl shadow-xl animate-slide-in overflow-hidden`}
        onClick={handleModalClick} data-id="7ysm9j2pk" data-path="components/Modal.js">

        <div className="flex items-center justify-between p-4 border-b border-gray-700" data-id="mfcu6awp9" data-path="components/Modal.js">
          <h3 className="text-lg font-semibold text-white" data-id="melxhk1yy" data-path="components/Modal.js">{title}</h3>
          <button
            className="text-gray-400 hover:text-white transition-colors"
            onClick={onClose}
            aria-label="Close" data-id="3w5n3bwzv" data-path="components/Modal.js">

            <i className="fas fa-times" data-id="0xy3q1qho" data-path="components/Modal.js"></i>
          </button>
        </div>
        
        <div className="p-4 max-h-[70vh] overflow-y-auto" data-id="zspvj8vg6" data-path="components/Modal.js">
          {children}
        </div>
        
        {footer &&
        <div className="p-4 border-t border-gray-700 bg-gray-800 bg-opacity-50" data-id="s3m7yjmoa" data-path="components/Modal.js">
            {footer}
          </div>
        }
      </div>
    </div>);

};

// Confirmation Modal for delete/confirm operations
const ConfirmModal = ({
  isOpen,
  onClose,
  onConfirm,
  title = 'Confirm Action',
  message = 'Are you sure you want to proceed?',
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  variant = 'danger'
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={title}
      size="sm"
      footer={
      <div className="flex justify-end space-x-3" data-id="yqkicrel5" data-path="components/Modal.js">
          <Button
          variant="ghost"
          onClick={onClose}>

            {cancelText}
          </Button>
          <Button
          variant={variant}
          onClick={() => {
            onConfirm();
            onClose();
          }}>

            {confirmText}
          </Button>
        </div>
      }>

      <p className="text-gray-300" data-id="40c12or8z" data-path="components/Modal.js">{message}</p>
    </Modal>);

};