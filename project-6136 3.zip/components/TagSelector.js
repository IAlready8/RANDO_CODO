// Component for selecting multiple tags

const TagSelector = ({
  availableTags = [],
  selectedTags = [],
  onTagSelect,
  onTagCreate,
  maxTags = 5
}) => {
  const { useState } = React;
  const [newTagInput, setNewTagInput] = useState('');
  const [showCreateField, setShowCreateField] = useState(false);

  // Filter available tags to exclude already selected
  const filteredTags = availableTags.filter((tag) =>
  !selectedTags.includes(tag.name)
  );

  // Handle tag selection
  const handleSelect = (tag) => {
    if (onTagSelect && selectedTags.length < maxTags) {
      onTagSelect(tag);
    }
  };

  // Handle creating a new tag
  const handleCreateTag = () => {
    if (!newTagInput.trim()) return;

    // Check if tag already exists in available tags
    const exists = availableTags.some((tag) =>
    tag.name.toLowerCase() === newTagInput.trim().toLowerCase()
    );

    if (exists) {
      // Find and select the existing tag
      const existingTag = availableTags.find((tag) =>
      tag.name.toLowerCase() === newTagInput.trim().toLowerCase()
      );
      handleSelect(existingTag);
    } else if (onTagCreate) {
      // Create a new tag
      onTagCreate(newTagInput.trim());
    }

    // Reset input
    setNewTagInput('');
    setShowCreateField(false);
  };

  return (
    <div className="tag-selector" data-id="urfdlpkct" data-path="components/TagSelector.js">
      {/* Selected Tags */}
      <div className="mb-3" data-id="q407cbiip" data-path="components/TagSelector.js">
        <div className="text-sm text-gray-400 mb-2" data-id="2w9kpa4i6" data-path="components/TagSelector.js">Selected Tags ({selectedTags.length}/{maxTags})</div>
        {selectedTags.length > 0 ?
        <div className="flex flex-wrap gap-2" data-id="g0fc5fkl4" data-path="components/TagSelector.js">
            {selectedTags.map((tag, index) =>
          <div
            key={index}
            className="bg-primary bg-opacity-20 text-primary rounded-full px-3 py-1 text-sm flex items-center" data-id="j02pb49da" data-path="components/TagSelector.js">

                <i className="fas fa-tag mr-1" data-id="l7g9u1qcr" data-path="components/TagSelector.js"></i>
                <span data-id="gazlw8bkz" data-path="components/TagSelector.js">{tag}</span>
                <button
              className="ml-2 text-primary-light hover:text-primary-dark"
              onClick={() => onTagSelect(tag)} data-id="xm2isv2yu" data-path="components/TagSelector.js">

                  <i className="fas fa-times" data-id="ely1dvt8y" data-path="components/TagSelector.js"></i>
                </button>
              </div>
          )}
          </div> :

        <div className="text-gray-500 italic text-sm" data-id="sxj2orl7z" data-path="components/TagSelector.js">No tags selected</div>
        }
      </div>
      
      {/* Create New Tag Input */}
      {showCreateField ?
      <div className="mb-3" data-id="hby57fzlc" data-path="components/TagSelector.js">
          <div className="flex" data-id="9vb1y7rtk" data-path="components/TagSelector.js">
            <input
            type="text"
            className="auth-input rounded-r-none"
            placeholder="Enter new tag name"
            value={newTagInput}
            onChange={(e) => setNewTagInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleCreateTag();
              }
            }} data-id="5vqyqhkog" data-path="components/TagSelector.js" />

            <Button
            className="rounded-l-none"
            onClick={handleCreateTag}
            disabled={!newTagInput.trim()}>

              Add
            </Button>
          </div>
        </div> :

      <div className="mb-3" data-id="4bkbhbx0t" data-path="components/TagSelector.js">
          <Button
          variant="outline"
          size="sm"
          fullWidth
          onClick={() => setShowCreateField(true)}
          disabled={selectedTags.length >= maxTags}
          icon={<i className="fas fa-plus" data-id="kjmeev3mj" data-path="components/TagSelector.js"></i>}>

            Create New Tag
          </Button>
        </div>
      }
      
      {/* Available Tags */}
      <div data-id="ut6oyyg6q" data-path="components/TagSelector.js">
        <div className="text-sm text-gray-400 mb-2" data-id="ruihwxehe" data-path="components/TagSelector.js">Available Tags</div>
        {filteredTags.length > 0 ?
        <div className="flex flex-wrap gap-2" data-id="ivrprdccf" data-path="components/TagSelector.js">
            {filteredTags.map((tag, index) =>
          <div
            key={index}
            className="bg-darklight hover:bg-gray-700 cursor-pointer transition-colors text-gray-300 rounded-full px-3 py-1 text-sm flex items-center"
            onClick={() => handleSelect(tag)} data-id="1cgohxb8s" data-path="components/TagSelector.js">

                <i className="fas fa-tag mr-1" data-id="5v8w4616v" data-path="components/TagSelector.js"></i>
                <span data-id="53brz73zw" data-path="components/TagSelector.js">{tag.name}</span>
                <span className="ml-2 text-xs bg-black bg-opacity-30 px-1.5 py-0.5 rounded-full" data-id="bsxw0tepa" data-path="components/TagSelector.js">
                  {tag.count}
                </span>
              </div>
          )}
          </div> :

        <div className="text-gray-500 italic text-sm" data-id="j48dea60t" data-path="components/TagSelector.js">No more tags available</div>
        }
      </div>
    </div>);

};