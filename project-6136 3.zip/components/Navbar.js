// Top navigation bar component

const Navbar = ({ toggleSidebar }) => {
  const { useState, useRef, useEffect } = React;
  const { currentUser, logout } = useAuth();
  const { toggleDarkMode, darkMode } = useTheme();
  const navigate = ReactRouterDOM.useNavigate();

  const [searchTerm, setSearchTerm] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const userMenuRef = useRef(null);

  // Close user menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setShowUserMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle search input
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  // Handle search form submission
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  // Handle user logout
  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <nav className="navbar" data-id="m44xiflqw" data-path="components/Navbar.js">
      <div className="navbar-left" data-id="2x9cqm6v2" data-path="components/Navbar.js">
        <button className="navbar-mobile-toggle" onClick={toggleSidebar} data-id="kpx05cra8" data-path="components/Navbar.js">
          <i className="fas fa-bars" data-id="jyiivq61u" data-path="components/Navbar.js"></i>
        </button>
        
        <form className="navbar-search" onSubmit={handleSearchSubmit} data-id="99rgcetnc" data-path="components/Navbar.js">
          <i className="fas fa-search navbar-search-icon" data-id="excszx9wg" data-path="components/Navbar.js"></i>
          <input
            type="text"
            className="navbar-search-input"
            placeholder="Search prompts..."
            value={searchTerm}
            onChange={handleSearch} data-id="jnjxdjg6f" data-path="components/Navbar.js" />

        </form>
      </div>
      
      <div className="navbar-right" data-id="jr59se0cz" data-path="components/Navbar.js">
        <button
          className="theme-toggle"
          onClick={toggleDarkMode}
          aria-label="Toggle Dark Mode" data-id="v81kteo5a" data-path="components/Navbar.js">

          {darkMode ?
          <i className="fas fa-sun text-yellow-400" data-id="xy1b0g893" data-path="components/Navbar.js"></i> :

          <i className="fas fa-moon text-blue-400" data-id="j8xf052f7" data-path="components/Navbar.js"></i>
          }
        </button>
        
        <button className="navbar-action" aria-label="Notifications" data-id="xrxwvuaqo" data-path="components/Navbar.js">
          <i className="fas fa-bell" data-id="ml9tr44pt" data-path="components/Navbar.js"></i>
        </button>
        
        <div className="relative" ref={userMenuRef} data-id="vfhluaj9q" data-path="components/Navbar.js">
          <button
            className="navbar-action flex items-center"
            onClick={() => setShowUserMenu(!showUserMenu)}
            aria-label="User Menu" data-id="ua2l4ca89" data-path="components/Navbar.js">

            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-semibold mr-2" data-id="t2mvg9dck" data-path="components/Navbar.js">
              {getInitials(currentUser?.name || 'User')}
            </div>
            <span className="hidden md:block" data-id="pfm7bgjfy" data-path="components/Navbar.js">{currentUser?.name || 'User'}</span>
            <i className="fas fa-chevron-down ml-2 text-xs" data-id="q2633mpit" data-path="components/Navbar.js"></i>
          </button>
          
          {showUserMenu &&
          <div className="absolute right-0 mt-2 w-48 bg-darklight rounded-md shadow-lg z-50 animate-fade-in border border-gray-700" data-id="v26xuvo2t" data-path="components/Navbar.js">
              <div className="py-2" data-id="45jzwiu4m" data-path="components/Navbar.js">
                <div className="px-4 py-2 text-sm text-gray-300 border-b border-gray-700" data-id="pomsnmhcb" data-path="components/Navbar.js">
                  <div className="font-semibold" data-id="eidx5aaq3" data-path="components/Navbar.js">{currentUser?.name || 'User'}</div>
                  <div className="text-xs truncate" data-id="3t5r8yhi9" data-path="components/Navbar.js">{currentUser?.email || 'user@example.com'}</div>
                </div>
                
                <ReactRouterDOM.Link
                to="/settings"
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 cursor-pointer"
                onClick={() => setShowUserMenu(false)}>

                  <i className="fas fa-cog mr-2" data-id="p41aezhzi" data-path="components/Navbar.js"></i> Settings
                </ReactRouterDOM.Link>
                
                <ReactRouterDOM.Link
                to="/analytics"
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 cursor-pointer"
                onClick={() => setShowUserMenu(false)}>

                  <i className="fas fa-chart-line mr-2" data-id="s5jd6ytir" data-path="components/Navbar.js"></i> Analytics
                </ReactRouterDOM.Link>
                
                <div
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 cursor-pointer"
                onClick={handleLogout} data-id="0795ffhlo" data-path="components/Navbar.js">

                  <i className="fas fa-sign-out-alt mr-2" data-id="9gpio1zy8" data-path="components/Navbar.js"></i> Logout
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </nav>);

};