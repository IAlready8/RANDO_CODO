// Chart components for analytics

// Bar Chart Component
const BarChart = ({ data = [], labelKey = 'name', valueKey = 'value', color = '#9333ea' }) => {
  const { useMemo } = React;

  // Find the maximum value for scaling
  const maxValue = useMemo(() => {
    return Math.max(...data.map((item) => item[valueKey]), 1);
  }, [data, valueKey]);

  // Empty state
  if (!data.length) {
    return (
      <div className="flex items-center justify-center h-48 text-gray-400" data-id="qbmr37170" data-path="components/Charts.js">
        No data available
      </div>);

  }

  return (
    <div className="chart-container" data-id="8ulmtidiv" data-path="components/Charts.js">
      <div className="flex h-64 items-end space-x-2" data-id="wcyvjnl6u" data-path="components/Charts.js">
        {data.map((item, index) => {
          const height = item[valueKey] / maxValue * 100;

          return (
            <div
              key={index}
              className="flex flex-col items-center flex-1" data-id="63up5lari" data-path="components/Charts.js">

              <div
                className="w-full bg-opacity-20 rounded-t relative bar-animation"
                style={{
                  height: `${height}%`,
                  backgroundColor: color,
                  minHeight: '4px'
                }} data-id="k11nfbmga" data-path="components/Charts.js">

                <div
                  className="absolute top-0 left-0 right-0 -mt-6 text-center text-xs"
                  style={{ color }} data-id="rs3c50keh" data-path="components/Charts.js">

                  {item[valueKey]}
                </div>
              </div>
              <div className="text-xs mt-2 text-gray-400 truncate text-center w-full px-1" data-id="6rf8453ja" data-path="components/Charts.js">
                {item[labelKey]}
              </div>
            </div>);

        })}
      </div>
    </div>);

};

// Line Chart Component
const LineChart = ({ data = [], xKey = 'month', yKey = 'count', color = '#9333ea' }) => {
  const { useMemo } = React;

  // Find the maximum value for scaling
  const maxValue = useMemo(() => {
    return Math.max(...data.map((item) => item[yKey]), 1);
  }, [data, yKey]);

  // Calculate points for the line
  const points = useMemo(() => {
    if (!data.length) return '';

    const step = 100 / (data.length - 1 || 1);

    return data.map((item, index) => {
      const x = index * step;
      const y = 100 - item[yKey] / maxValue * 100;
      return `${x},${y}`;
    }).join(' ');
  }, [data, yKey, maxValue]);

  // Empty state
  if (!data.length) {
    return (
      <div className="flex items-center justify-center h-48 text-gray-400" data-id="dc1otyctb" data-path="components/Charts.js">
        No data available
      </div>);

  }

  return (
    <div className="chart-container" data-id="q8of890jl" data-path="components/Charts.js">
      <svg viewBox="0 0 100 100" className="w-full h-64 overflow-visible" data-id="30ielopq7" data-path="components/Charts.js">
        {/* X and Y axes */}
        <line x1="0" y1="100" x2="100" y2="100" stroke="rgba(107, 114, 128, 0.2)" strokeWidth="0.5" data-id="3rn3t9sj6" data-path="components/Charts.js" />
        <line x1="0" y1="0" x2="0" y2="100" stroke="rgba(107, 114, 128, 0.2)" strokeWidth="0.5" data-id="4mij8iczo" data-path="components/Charts.js" />
        
        {/* Horizontal grid lines */}
        {[25, 50, 75].map((y) =>
        <line
          key={y}
          x1="0"
          y1={y}
          x2="100"
          y2={y}
          stroke="rgba(107, 114, 128, 0.1)"
          strokeWidth="0.5"
          strokeDasharray="1,1" data-id="a7vw1e2i8" data-path="components/Charts.js" />

        )}
        
        {/* The line */}
        <polyline
          points={points}
          fill="none"
          stroke={color}
          strokeWidth="2"
          className="line-animation" data-id="el0a14g29" data-path="components/Charts.js" />

        
        {/* Data points */}
        {data.map((item, index) => {
          const step = 100 / (data.length - 1 || 1);
          const x = index * step;
          const y = 100 - item[yKey] / maxValue * 100;

          return (
            <g key={index} data-id="k7gwosf7i" data-path="components/Charts.js">
              <circle
                cx={x}
                cy={y}
                r="1.5"
                fill={color}
                stroke="white"
                strokeWidth="1" data-id="2o9ib3bkw" data-path="components/Charts.js" />

              
              {/* Value labels */}
              <text
                x={x}
                y={y - 5}
                textAnchor="middle"
                fontSize="4"
                fill={color} data-id="5e6nsi5ve" data-path="components/Charts.js">

                {item[yKey]}
              </text>
              
              {/* X-axis labels */}
              <text
                x={x}
                y="105"
                textAnchor="middle"
                fontSize="3"
                fill="#6B7280" data-id="3ab8kem8m" data-path="components/Charts.js">

                {item[xKey]}
              </text>
            </g>);

        })}
      </svg>
    </div>);

};

// Pie Chart Component
const PieChart = ({ data = [], labelKey = 'name', valueKey = 'value' }) => {
  const { useMemo } = React;

  // Calculate total for percentages
  const total = useMemo(() => {
    return data.reduce((sum, item) => sum + item[valueKey], 0);
  }, [data, valueKey]);

  // Generate colors for each slice
  const colors = useMemo(() => {
    return data.map((item) => stringToColor(item[labelKey]));
  }, [data, labelKey]);

  // Calculate pie slices
  const slices = useMemo(() => {
    if (!data.length || total === 0) return [];

    let startAngle = 0;
    return data.map((item, index) => {
      const percentage = item[valueKey] / total;
      const angle = percentage * 360;
      const endAngle = startAngle + angle;

      // Calculate SVG arc path
      const x1 = 50 + 40 * Math.cos((startAngle - 90) * Math.PI / 180);
      const y1 = 50 + 40 * Math.sin((startAngle - 90) * Math.PI / 180);
      const x2 = 50 + 40 * Math.cos((endAngle - 90) * Math.PI / 180);
      const y2 = 50 + 40 * Math.sin((endAngle - 90) * Math.PI / 180);

      // Determine if the arc should take the long path or not
      const largeArcFlag = angle > 180 ? 1 : 0;

      const path = `
        M 50 50
        L ${x1} ${y1}
        A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2}
        Z
      `;

      const slice = {
        path,
        color: colors[index],
        percentage,
        label: item[labelKey],
        value: item[valueKey],
        startAngle,
        endAngle
      };

      startAngle = endAngle;
      return slice;
    });
  }, [data, total, labelKey, valueKey, colors]);

  // Empty state
  if (!data.length || total === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-gray-400" data-id="0mz5tsijh" data-path="components/Charts.js">
        No data available
      </div>);

  }

  return (
    <div data-id="qka35ptpy" data-path="components/Charts.js">
      <div className="chart-container" data-id="cqb5auqzv" data-path="components/Charts.js">
        <svg viewBox="0 0 100 100" className="w-full h-64" data-id="kym1j0skr" data-path="components/Charts.js">
          {slices.map((slice, index) =>
          <path
            key={index}
            d={slice.path}
            fill={slice.color}
            stroke="#121212"
            strokeWidth="1"
            className="transition-opacity hover:opacity-80" data-id="pxh6s8b9s" data-path="components/Charts.js" />

          )}
          
          {/* Center circle cutout for donut effect */}
          <circle
            cx="50"
            cy="50"
            r="25"
            fill="#1e1e1e"
            stroke="#121212"
            strokeWidth="1" data-id="48idrov9h" data-path="components/Charts.js" />

          
          {/* Display total in the center */}
          <text
            x="50"
            y="48"
            textAnchor="middle"
            fontSize="10"
            fill="white"
            fontWeight="bold" data-id="q9o850jpa" data-path="components/Charts.js">

            {total}
          </text>
          <text
            x="50"
            y="56"
            textAnchor="middle"
            fontSize="5"
            fill="#6B7280" data-id="vcvh03qb8" data-path="components/Charts.js">

            Total
          </text>
        </svg>
      </div>
      
      <div className="chart-legend" data-id="8hzcqc55p" data-path="components/Charts.js">
        {slices.map((slice, index) =>
        <div key={index} className="legend-item" data-id="fjaz9fova" data-path="components/Charts.js">
            <div
            className="legend-color"
            style={{ backgroundColor: slice.color }} data-id="rmjdnujrm" data-path="components/Charts.js">
          </div>
            <div className="text-sm" data-id="k5nxcqi14" data-path="components/Charts.js">
              <span className="text-white" data-id="tsonw65d6" data-path="components/Charts.js">{slice.label}</span>
              <span className="text-gray-400 ml-1" data-id="sm5x50foc" data-path="components/Charts.js">
                ({slice.value}, {Math.round(slice.percentage * 100)}%)
              </span>
            </div>
          </div>
        )}
      </div>
    </div>);

};