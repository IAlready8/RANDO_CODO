// Component for displaying a list of prompts

const PromptList = ({
  prompts = [],
  loading = false,
  category = null,
  tag = null,
  showFilters = true,
  limit = null
}) => {
  const { useState, useMemo } = React;
  const navigate = ReactRouterDOM.useNavigate();
  const { deletePrompt } = usePrompts();

  const [sortBy, setSortBy] = useState('newest');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [promptToDelete, setPromptToDelete] = useState(null);

  // Apply sorting to prompts
  const sortedPrompts = useMemo(() => {
    return sortPrompts(prompts, sortBy);
  }, [prompts, sortBy]);

  // Apply limit if specified
  const displayPrompts = useMemo(() => {
    return limit ? sortedPrompts.slice(0, limit) : sortedPrompts;
  }, [sortedPrompts, limit]);

  // Handle prompt item click (navigate to detail)
  const handlePromptClick = (prompt) => {
    navigate(`/prompt/${prompt.id}`);
  };

  // Handle delete button click
  const handleDeleteClick = (e, prompt) => {
    e.stopPropagation(); // Prevent navigation to detail
    setPromptToDelete(prompt);
    setShowDeleteModal(true);
  };

  // Handle edit button click
  const handleEditClick = (e, prompt) => {
    e.stopPropagation(); // Prevent navigation to detail
    navigate(`/edit-prompt/${prompt.id}`);
  };

  // Handle copy button click
  const handleCopyClick = (e, prompt) => {
    e.stopPropagation(); // Prevent navigation to detail
    copyToClipboard(prompt.content);

    // Show temporary copied message
    const button = e.currentTarget;
    const originalHTML = button.innerHTML;
    button.innerHTML = '<i class="fas fa-check"></i>';

    setTimeout(() => {
      button.innerHTML = originalHTML;
    }, 2000);
  };

  // Handle confirm delete
  const handleConfirmDelete = async () => {
    if (promptToDelete) {
      await deletePrompt(promptToDelete.id);
    }
  };

  // Empty state when no prompts
  if (prompts.length === 0 && !loading) {
    return (
      <div className="empty-state" data-id="sscr4zbxh" data-path="components/PromptList.js">
        <div className="empty-state-icon" data-id="bqnfxbb37" data-path="components/PromptList.js">
          <i className="fas fa-file-alt" data-id="39q4l8c7x" data-path="components/PromptList.js"></i>
        </div>
        <h3 className="empty-state-title" data-id="g3smcfwcb" data-path="components/PromptList.js">No prompts found</h3>
        <p className="empty-state-description" data-id="068esgukj" data-path="components/PromptList.js">
          {category ?
          `No prompts found in the "${category}" category.` :
          tag ?
          `No prompts found with the "${tag}" tag.` :
          'Get started by creating your first prompt!'}
        </p>
        <Button
          onClick={() => navigate('/new-prompt')}
          icon={<i className="fas fa-plus" data-id="kl6jkzeqd" data-path="components/PromptList.js"></i>}>

          Create New Prompt
        </Button>
      </div>);

  }

  return (
    <div data-id="uv7vctnz7" data-path="components/PromptList.js">
      {showFilters &&
      <div className="flex justify-between items-center mb-4" data-id="ueh4c7vw1" data-path="components/PromptList.js">
          <div className="text-sm text-gray-400" data-id="9nvu62nsx" data-path="components/PromptList.js">
            {prompts.length} {prompts.length === 1 ? 'prompt' : 'prompts'} found
            {category && <span data-id="56t2t0tty" data-path="components/PromptList.js"> in <span className="text-secondary" data-id="tcahqzciq" data-path="components/PromptList.js">{category}</span></span>}
            {tag && <span data-id="dd5outogs" data-path="components/PromptList.js"> with tag <span className="text-primary" data-id="70w30918m" data-path="components/PromptList.js">{tag}</span></span>}
          </div>
          
          <div className="flex items-center" data-id="r8hyrdaxd" data-path="components/PromptList.js">
            <label className="text-sm text-gray-400 mr-2" data-id="1hvpjzkiu" data-path="components/PromptList.js">Sort by:</label>
            <select
            className="bg-darklight border border-gray-700 text-white rounded-md text-sm p-1"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)} data-id="5xup65383" data-path="components/PromptList.js">

              <option value="newest" data-id="vgczsxeqx" data-path="components/PromptList.js">Newest</option>
              <option value="oldest" data-id="ozh9ujobp" data-path="components/PromptList.js">Oldest</option>
              <option value="updated" data-id="3i1bxafjl" data-path="components/PromptList.js">Recently Updated</option>
              <option value="title" data-id="ktmseoj8o" data-path="components/PromptList.js">Title</option>
              <option value="usage" data-id="4wlsa92hs" data-path="components/PromptList.js">Usage Count</option>
            </select>
          </div>
        </div>
      }
      
      {loading ?
      <div className="flex justify-center py-8" data-id="00dsaw8cf" data-path="components/PromptList.js">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary" data-id="5f4v8kon2" data-path="components/PromptList.js"></div>
        </div> :

      <div className="prompt-list" data-id="bxktm6meg" data-path="components/PromptList.js">
          {displayPrompts.map((prompt) =>
        <div
          key={prompt.id}
          className="prompt-item"
          onClick={() => handlePromptClick(prompt)} data-id="exsvxufkc" data-path="components/PromptList.js">

              <div className="prompt-item-header" data-id="41kztvde0" data-path="components/PromptList.js">
                <div className="prompt-item-title" data-id="ahoh41vl3" data-path="components/PromptList.js">{prompt.title}</div>
                <div className="prompt-item-date" data-id="ahh5zoho2" data-path="components/PromptList.js">{timeAgo(prompt.updatedAt)}</div>
              </div>
              
              <div className="prompt-item-content" data-id="pclqbi3j6" data-path="components/PromptList.js">
                {truncateText(prompt.content, 150)}
              </div>
              
              <div className="prompt-item-footer" data-id="089rafce7" data-path="components/PromptList.js">
                <div className="prompt-item-tags" data-id="ozepal8wj" data-path="components/PromptList.js">
                  <div className="prompt-category" data-id="an9ctgu0o" data-path="components/PromptList.js">
                    {prompt.category}
                  </div>
                  {prompt.tags.slice(0, 2).map((tag, i) =>
              <div key={i} className="prompt-tag" data-id="j9qcqk4am" data-path="components/PromptList.js">
                      {tag}
                    </div>
              )}
                  {prompt.tags.length > 2 &&
              <div className="prompt-tag" data-id="f39eu05q4" data-path="components/PromptList.js">
                      +{prompt.tags.length - 2}
                    </div>
              }
                </div>
                
                <div className="prompt-item-actions" data-id="uejt6igcq" data-path="components/PromptList.js">
                  <button
                className="prompt-action"
                onClick={(e) => handleCopyClick(e, prompt)}
                title="Copy prompt" data-id="ax12whamp" data-path="components/PromptList.js">

                    <i className="fas fa-copy" data-id="xp5qszmls" data-path="components/PromptList.js"></i>
                  </button>
                  <button
                className="prompt-action"
                onClick={(e) => handleEditClick(e, prompt)}
                title="Edit prompt" data-id="er5t677kl" data-path="components/PromptList.js">

                    <i className="fas fa-edit" data-id="g0scarjew" data-path="components/PromptList.js"></i>
                  </button>
                  <button
                className="prompt-action"
                onClick={(e) => handleDeleteClick(e, prompt)}
                title="Delete prompt" data-id="c9ydvnwss" data-path="components/PromptList.js">

                    <i className="fas fa-trash-alt" data-id="tu9521sdu" data-path="components/PromptList.js"></i>
                  </button>
                </div>
              </div>
            </div>
        )}
        </div>
      }
      
      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Prompt"
        message="Are you sure you want to delete this prompt? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger" />

    </div>);

};