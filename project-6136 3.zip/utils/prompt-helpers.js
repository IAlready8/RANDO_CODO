// Helper functions for prompt-related operations

// Format a prompt from database format to application format
function formatPromptFromDb(dbPrompt, category, tags = []) {
  return {
    id: dbPrompt.ID.toString(),
    title: dbPrompt.title,
    content: dbPrompt.content,
    category: category?.name || 'General',
    categoryId: dbPrompt.category_id,
    tags: tags.map((t) => t.name) || [],
    tagIds: tags.map((t) => t.ID) || [],
    isFavorite: dbPrompt.is_favorite || false,
    usage: dbPrompt.usage_count || 0,
    createdAt: dbPrompt.created_at,
    updatedAt: dbPrompt.updated_at,
    userId: dbPrompt.user_id
  };
}

// Format a prompt for sending to the database
function formatPromptForDb(prompt) {
  return {
    title: prompt.title,
    content: prompt.content,
    category_id: prompt.categoryId,
    is_favorite: prompt.isFavorite || false,
    usage_count: prompt.usage || 0,
    user_id: prompt.userId
  };
}

// Get a category name from id
async function getCategoryNameById(categoryId) {
  try {
    if (!categoryId) return 'General';

    const CATEGORIES_TABLE_ID = 3556; // Fixed ID based on table creation

    const queryParams = {
      PageNo: 1,
      PageSize: 1,
      Filters: [
      {
        name: "ID",
        op: "Equal",
        value: categoryId
      }]

    };

    const response = await window.ezsite.apis.tablePage(CATEGORIES_TABLE_ID, queryParams);

    if (response.error) {
      console.error('Error fetching category:', response.error);
      return 'General';
    }

    if (response.data.List.length === 0) {
      return 'General';
    }

    return response.data.List[0].name;
  } catch (error) {
    console.error('Error getting category name:', error);
    return 'General';
  }
}

// Generate analytics data with promise-based approach
function generatePromptAnalytics(prompts, categories, tags) {
  // Count prompts by category
  const promptsByCategory = [];
  const categoryMap = {};

  categories.forEach((category) => {
    categoryMap[category.id] = { name: category.name, count: 0 };
  });

  prompts.forEach((prompt) => {
    if (prompt.categoryId && categoryMap[prompt.categoryId]) {
      categoryMap[prompt.categoryId].count++;
    }
  });

  Object.values(categoryMap).forEach((category) => {
    if (category.count > 0) {
      promptsByCategory.push({
        name: category.name,
        value: category.count
      });
    }
  });

  // Count prompts by month
  const monthData = {};
  prompts.forEach((prompt) => {
    const date = new Date(prompt.createdAt);
    const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
    monthData[monthYear] = (monthData[monthYear] || 0) + 1;
  });

  const promptsByMonth = Object.keys(monthData).
  sort((a, b) => {
    const [aMonth, aYear] = a.split('/').map(Number);
    const [bMonth, bYear] = b.split('/').map(Number);
    return aYear * 12 + aMonth - (bYear * 12 + bMonth);
  }).
  map((monthYear) => ({
    month: monthYear,
    count: monthData[monthYear]
  }));

  // Get top tags
  const topTags = [...tags].
  sort((a, b) => b.count - a.count).
  slice(0, 5);

  return {
    totalPrompts: prompts.length,
    promptsByCategory,
    promptsByMonth,
    topTags
  };
}