// Authentication utility functions

// Check if user is logged in
function isLoggedIn() {
  return localStorage.getItem('user') !== null;
}

// Get current user from localStorage
function getCurrentUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

// Login a user (store in localStorage)
function loginUser(user) {
  localStorage.setItem('user', JSON.stringify(user));
}

// Logout a user (remove from localStorage)
function logoutUser() {
  localStorage.removeItem('user');
}

// Register a new user
function registerUser(user) {
  // Get existing users or create empty array
  const users = JSON.parse(localStorage.getItem('users') || '[]');

  // Add new user
  users.push(user);

  // Save back to localStorage
  localStorage.setItem('users', JSON.stringify(users));

  // Also log in the user
  const { password, ...userWithoutPassword } = user;
  loginUser(userWithoutPassword);

  return userWithoutPassword;
}

// Check if a user exists with given email
function userExists(email) {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  return users.some((user) => user.email === email);
}

// Validate a user's credentials
function validateCredentials(email, password) {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const user = users.find((user) => user.email === email && user.password === password);

  if (!user) {
    return { valid: false, user: null };
  }

  // Return user without password
  const { password: _, ...userWithoutPassword } = user;
  return { valid: true, user: userWithoutPassword };
}

// Update a user's profile
function updateUserProfile(userId, updates) {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const userIndex = users.findIndex((user) => user.id === userId);

  if (userIndex === -1) {
    throw new Error('User not found');
  }

  // Update user
  users[userIndex] = { ...users[userIndex], ...updates };

  // Save back to localStorage
  localStorage.setItem('users', JSON.stringify(users));

  // Update current user if it's the same
  const currentUser = getCurrentUser();
  if (currentUser && currentUser.id === userId) {
    const { password, ...userWithoutPassword } = users[userIndex];
    loginUser(userWithoutPassword);
    return userWithoutPassword;
  }

  return null;
}