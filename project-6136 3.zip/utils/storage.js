// Storage utility functions

// Save data to localStorage with user scope
function saveUserData(userId, key, data) {
  const storageKey = `${key}_${userId}`;
  localStorage.setItem(storageKey, JSON.stringify(data));
}

// Get data from localStorage with user scope
function getUserData(userId, key, defaultValue = null) {
  const storageKey = `${key}_${userId}`;
  const data = localStorage.getItem(storageKey);
  return data ? JSON.parse(data) : defaultValue;
}

// Save a prompt to localStorage
function savePrompt(userId, prompt) {
  // Get existing prompts
  const prompts = getUserData(userId, 'prompts', []);

  // Add new prompt or update existing
  const existingIndex = prompts.findIndex((p) => p.id === prompt.id);
  if (existingIndex > -1) {
    prompts[existingIndex] = { ...prompts[existingIndex], ...prompt, updatedAt: new Date().toISOString() };
  } else {
    prompts.unshift(prompt);
  }

  // Save back to localStorage
  saveUserData(userId, 'prompts', prompts);

  return prompt;
}

// Delete a prompt from localStorage
function deletePrompt(userId, promptId) {
  // Get existing prompts
  const prompts = getUserData(userId, 'prompts', []);

  // Remove prompt
  const updatedPrompts = prompts.filter((p) => p.id !== promptId);

  // Save back to localStorage
  saveUserData(userId, 'prompts', updatedPrompts);

  return true;
}

// Save categories to localStorage
function saveCategories(userId, categories) {
  saveUserData(userId, 'categories', categories);
}

// Save tags to localStorage
function saveTags(userId, tags) {
  saveUserData(userId, 'tags', tags);
}

// Clear all user data
function clearUserData(userId) {
  const keys = ['prompts', 'categories', 'tags', 'settings', 'history'];
  keys.forEach((key) => {
    localStorage.removeItem(`${key}_${userId}`);
  });
}

// Export user data as JSON
function exportUserData(userId) {
  const data = {
    prompts: getUserData(userId, 'prompts', []),
    categories: getUserData(userId, 'categories', []),
    tags: getUserData(userId, 'tags', []),
    settings: getUserData(userId, 'settings', {}),
    history: getUserData(userId, 'history', [])
  };

  return JSON.stringify(data, null, 2);
}

// Import user data from JSON
function importUserData(userId, jsonData) {
  try {
    const data = JSON.parse(jsonData);

    if (data.prompts) saveUserData(userId, 'prompts', data.prompts);
    if (data.categories) saveUserData(userId, 'categories', data.categories);
    if (data.tags) saveUserData(userId, 'tags', data.tags);
    if (data.settings) saveUserData(userId, 'settings', data.settings);
    if (data.history) saveUserData(userId, 'history', data.history);

    return true;
  } catch (error) {
    console.error('Error importing data:', error);
    return false;
  }
}