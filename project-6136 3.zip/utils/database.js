// Database utility functions for API integration

// Table IDs
let PROMPTS_TABLE_ID = null;
let CATEGORIES_TABLE_ID = null;
let TAGS_TABLE_ID = null;
let PROMPT_TAGS_TABLE_ID = null;

// Initialize database tables
async function initializeTables() {
  try {
    console.log('Initializing database tables...');

    // Create or get Prompts table
    if (!PROMPTS_TABLE_ID) {
      const promptsTable = await createPromptsTable();
      PROMPTS_TABLE_ID = promptsTable;
    }

    // Create or get Categories table
    if (!CATEGORIES_TABLE_ID) {
      const categoriesTable = await createCategoriesTable();
      CATEGORIES_TABLE_ID = categoriesTable;
    }

    // Create or get Tags table
    if (!TAGS_TABLE_ID) {
      const tagsTable = await createTagsTable();
      TAGS_TABLE_ID = tagsTable;
    }

    // Create or get PromptTags table
    if (!PROMPT_TAGS_TABLE_ID) {
      const promptTagsTable = await createPromptTagsTable();
      PROMPT_TAGS_TABLE_ID = promptTagsTable;
    }

    return {
      PROMPTS_TABLE_ID,
      CATEGORIES_TABLE_ID,
      TAGS_TABLE_ID,
      PROMPT_TAGS_TABLE_ID
    };
  } catch (error) {
    console.error('Error initializing tables:', error);
    throw error;
  }
}

// Create Prompts table
async function createPromptsTable() {
  try {
    // Define the Prompts table
    const response = await window.ezsite.apis.CreateOrUpdateTable({
      TableName: "prompts",
      TableDisplayName: "Prompts",
      TableDesc: "User-created AI prompts",
      FieldDefinitions: [
      {
        FieldName: "user_id",
        FieldDisplayName: "User ID",
        FieldDesc: "ID of the user who created the prompt",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "title",
        FieldDisplayName: "Title",
        FieldDesc: "Prompt title",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "content",
        FieldDisplayName: "Content",
        FieldDesc: "Actual prompt text content",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "category_id",
        FieldDisplayName: "Category ID",
        FieldDesc: "Reference to category",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "usage_count",
        FieldDisplayName: "Usage Count",
        FieldDesc: "Number of times prompt has been used",
        DefaultValue: "0",
        ValueType: "Integer",
        ComponentType: "Default"
      },
      {
        FieldName: "is_favorite",
        FieldDisplayName: "Is Favorite",
        FieldDesc: "Whether prompt is marked as favorite",
        DefaultValue: "false",
        ValueType: "Bool",
        ComponentType: "Default"
      },
      {
        FieldName: "created_at",
        FieldDisplayName: "Created At",
        FieldDesc: "When the prompt was created",
        DefaultValue: "",
        ValueType: "DateTime",
        ComponentType: "Default"
      },
      {
        FieldName: "updated_at",
        FieldDisplayName: "Updated At",
        FieldDesc: "When the prompt was last updated",
        DefaultValue: "",
        ValueType: "DateTime",
        ComponentType: "Default"
      }]

    });

    if (response.error) {
      throw new Error(response.error);
    }

    console.log('Prompts table created/updated successfully');
    return response.data;
  } catch (error) {
    console.error('Error creating prompts table:', error);
    throw error;
  }
}

// Create Categories table
async function createCategoriesTable() {
  try {
    // Define the Categories table
    const response = await window.ezsite.apis.CreateOrUpdateTable({
      TableName: "categories",
      TableDisplayName: "Categories",
      TableDesc: "Categories for organizing prompts",
      FieldDefinitions: [
      {
        FieldName: "user_id",
        FieldDisplayName: "User ID",
        FieldDesc: "ID of the user who created the category",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "name",
        FieldDisplayName: "Name",
        FieldDesc: "Category name",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "description",
        FieldDisplayName: "Description",
        FieldDesc: "Category description",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "count",
        FieldDisplayName: "Count",
        FieldDesc: "Number of prompts in this category",
        DefaultValue: "0",
        ValueType: "Integer",
        ComponentType: "Default"
      },
      {
        FieldName: "color",
        FieldDisplayName: "Color",
        FieldDesc: "Color code for the category",
        DefaultValue: "#9333ea",
        ValueType: "String",
        ComponentType: "Default"
      }]

    });

    if (response.error) {
      throw new Error(response.error);
    }

    console.log('Categories table created/updated successfully');
    return response.data;
  } catch (error) {
    console.error('Error creating categories table:', error);
    throw error;
  }
}

// Create Tags table
async function createTagsTable() {
  try {
    // Define the Tags table
    const response = await window.ezsite.apis.CreateOrUpdateTable({
      TableName: "tags",
      TableDisplayName: "Tags",
      TableDesc: "Tags for labeling prompts",
      FieldDefinitions: [
      {
        FieldName: "user_id",
        FieldDisplayName: "User ID",
        FieldDesc: "ID of the user who created the tag",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "name",
        FieldDisplayName: "Name",
        FieldDesc: "Tag name",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "count",
        FieldDisplayName: "Count",
        FieldDesc: "Number of prompts with this tag",
        DefaultValue: "0",
        ValueType: "Integer",
        ComponentType: "Default"
      }]

    });

    if (response.error) {
      throw new Error(response.error);
    }

    console.log('Tags table created/updated successfully');
    return response.data;
  } catch (error) {
    console.error('Error creating tags table:', error);
    throw error;
  }
}

// Create a prompt tag relationship table
async function createPromptTagsTable() {
  try {
    // Define the PromptTags table for many-to-many relationship
    const response = await window.ezsite.apis.CreateOrUpdateTable({
      TableName: "prompt_tags",
      TableDisplayName: "Prompt Tags",
      TableDesc: "Relationship between prompts and tags",
      FieldDefinitions: [
      {
        FieldName: "prompt_id",
        FieldDisplayName: "Prompt ID",
        FieldDesc: "ID of the prompt",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      },
      {
        FieldName: "tag_id",
        FieldDisplayName: "Tag ID",
        FieldDesc: "ID of the tag",
        DefaultValue: "",
        ValueType: "String",
        ComponentType: "Default"
      }]

    });

    if (response.error) {
      throw new Error(response.error);
    }

    console.log('PromptTags table created/updated successfully');
    return response.data;
  } catch (error) {
    console.error('Error creating prompt_tags table:', error);
    throw error;
  }
}

// Fetch prompts for a user
async function fetchPrompts(userId, filters = {}) {
  try {
    if (!PROMPTS_TABLE_ID) {
      await initializeTables();
    }

    const queryParams = {
      PageNo: filters.page || 1,
      PageSize: filters.pageSize || 20,
      OrderByField: filters.orderBy || "created_at",
      IsAsc: filters.orderDirection === "asc",
      Filters: [
      {
        name: "user_id",
        op: "Equal",
        value: userId
      }]

    };

    // Add category filter if provided
    if (filters.category) {
      queryParams.Filters.push({
        name: "category_id",
        op: "Equal",
        value: filters.category
      });
    }

    // Add search filter if provided
    if (filters.search) {
      queryParams.Filters.push({
        name: "title",
        op: "StringContains",
        value: filters.search
      });
    }

    const response = await window.ezsite.apis.tablePage(PROMPTS_TABLE_ID, queryParams);

    if (response.error) {
      throw new Error(response.error);
    }

    return {
      prompts: response.data.List,
      total: response.data.VirtualCount
    };
  } catch (error) {
    console.error('Error fetching prompts:', error);
    throw error;
  }
}

// Create a new prompt
async function createPrompt(promptData) {
  try {
    if (!PROMPTS_TABLE_ID) {
      await initializeTables();
    }

    const now = new Date().toISOString();

    const promptRecord = {
      user_id: promptData.userId,
      title: promptData.title,
      content: promptData.content,
      category_id: promptData.categoryId,
      usage_count: 0,
      is_favorite: false,
      created_at: now,
      updated_at: now
    };

    const response = await window.ezsite.apis.tableCreate(PROMPTS_TABLE_ID, promptRecord);

    if (response.error) {
      throw new Error(response.error);
    }

    // If tags are provided, create tag relationships
    if (promptData.tags && promptData.tags.length > 0) {
      await createPromptTagRelationships(response.data.ID, promptData.tags);
    }

    return response.data;
  } catch (error) {
    console.error('Error creating prompt:', error);
    throw error;
  }
}

// Update an existing prompt
async function updatePrompt(promptId, promptData) {
  try {
    if (!PROMPTS_TABLE_ID) {
      await initializeTables();
    }

    const updateData = {
      ID: promptId,
      ...promptData,
      updated_at: new Date().toISOString()
    };

    const response = await window.ezsite.apis.tableUpdate(PROMPTS_TABLE_ID, updateData);

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data;
  } catch (error) {
    console.error('Error updating prompt:', error);
    throw error;
  }
}

// Delete a prompt
async function deletePrompt(promptId) {
  try {
    if (!PROMPTS_TABLE_ID) {
      await initializeTables();
    }

    const response = await window.ezsite.apis.tableDelete(PROMPTS_TABLE_ID, { ID: promptId });

    if (response.error) {
      throw new Error(response.error);
    }

    return true;
  } catch (error) {
    console.error('Error deleting prompt:', error);
    throw error;
  }
}

// Create tag relationships for a prompt
async function createPromptTagRelationships(promptId, tagIds) {
  try {
    // Loop through tagIds and create relationships
    for (const tagId of tagIds) {
      const relationship = {
        prompt_id: promptId,
        tag_id: tagId
      };

      const response = await window.ezsite.apis.tableCreate(PROMPT_TAGS_TABLE_ID, relationship);

      if (response.error) {
        console.error('Error creating prompt-tag relationship:', response.error);
      }
    }

    return true;
  } catch (error) {
    console.error('Error creating prompt tag relationships:', error);
    throw error;
  }
}

// Fetch categories for a user
async function fetchCategories(userId) {
  try {
    if (!CATEGORIES_TABLE_ID) {
      await initializeTables();
    }

    const queryParams = {
      PageNo: 1,
      PageSize: 100, // Assuming we don't have more than 100 categories
      OrderByField: "name",
      IsAsc: true,
      Filters: [
      {
        name: "user_id",
        op: "Equal",
        value: userId
      }]

    };

    const response = await window.ezsite.apis.tablePage(CATEGORIES_TABLE_ID, queryParams);

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data.List;
  } catch (error) {
    console.error('Error fetching categories:', error);
    throw error;
  }
}

// Create a new category
async function createCategory(categoryData) {
  try {
    if (!CATEGORIES_TABLE_ID) {
      await initializeTables();
    }

    const categoryRecord = {
      user_id: categoryData.userId,
      name: categoryData.name,
      description: categoryData.description || '',
      count: 0,
      color: categoryData.color || '#9333ea'
    };

    const response = await window.ezsite.apis.tableCreate(CATEGORIES_TABLE_ID, categoryRecord);

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data;
  } catch (error) {
    console.error('Error creating category:', error);
    throw error;
  }
}

// Fetch tags for a user
async function fetchTags(userId) {
  try {
    if (!TAGS_TABLE_ID) {
      await initializeTables();
    }

    const queryParams = {
      PageNo: 1,
      PageSize: 200, // Assuming we don't have more than 200 tags
      OrderByField: "name",
      IsAsc: true,
      Filters: [
      {
        name: "user_id",
        op: "Equal",
        value: userId
      }]

    };

    const response = await window.ezsite.apis.tablePage(TAGS_TABLE_ID, queryParams);

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data.List;
  } catch (error) {
    console.error('Error fetching tags:', error);
    throw error;
  }
}

// Create a new tag
async function createTag(tagData) {
  try {
    if (!TAGS_TABLE_ID) {
      await initializeTables();
    }

    const tagRecord = {
      user_id: tagData.userId,
      name: tagData.name,
      count: 0
    };

    const response = await window.ezsite.apis.tableCreate(TAGS_TABLE_ID, tagRecord);

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data;
  } catch (error) {
    console.error('Error creating tag:', error);
    throw error;
  }
}

// Increment usage count for a prompt
async function incrementPromptUsage(promptId) {
  try {
    if (!PROMPTS_TABLE_ID) {
      await initializeTables();
    }

    // First get the current prompt to get its usage count
    const queryParams = {
      PageNo: 1,
      PageSize: 1,
      Filters: [
      {
        name: "ID",
        op: "Equal",
        value: promptId
      }]

    };

    const promptResponse = await window.ezsite.apis.tablePage(PROMPTS_TABLE_ID, queryParams);

    if (promptResponse.error) {
      throw new Error(promptResponse.error);
    }

    if (promptResponse.data.List.length === 0) {
      throw new Error('Prompt not found');
    }

    const prompt = promptResponse.data.List[0];
    const newUsageCount = (prompt.usage_count || 0) + 1;

    // Update the prompt with the new usage count
    const updateResponse = await window.ezsite.apis.tableUpdate(PROMPTS_TABLE_ID, {
      ID: promptId,
      usage_count: newUsageCount
    });

    if (updateResponse.error) {
      throw new Error(updateResponse.error);
    }

    return newUsageCount;
  } catch (error) {
    console.error('Error incrementing prompt usage:', error);
    throw error;
  }
}

// Generate analytics data
async function generateAnalytics(userId) {
  try {
    // Fetch all prompts
    const { prompts } = await fetchPrompts(userId, { pageSize: 1000 });

    // Fetch all categories
    const categories = await fetchCategories(userId);

    // Fetch all tags
    const tags = await fetchTags(userId);

    // Count prompts by category
    const promptsByCategory = [];
    categories.forEach((category) => {
      const count = prompts.filter((p) => p.category_id === category.ID).length;
      promptsByCategory.push({
        name: category.name,
        value: count
      });
    });

    // Count prompts by month
    const monthData = {};
    prompts.forEach((prompt) => {
      const date = new Date(prompt.created_at);
      const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
      monthData[monthYear] = (monthData[monthYear] || 0) + 1;
    });

    const promptsByMonth = Object.keys(monthData).
    sort((a, b) => {
      const [aMonth, aYear] = a.split('/').map(Number);
      const [bMonth, bYear] = b.split('/').map(Number);
      return aYear * 12 + aMonth - (bYear * 12 + bMonth);
    }).
    map((monthYear) => ({
      month: monthYear,
      count: monthData[monthYear]
    }));

    // Get top tags
    const topTags = tags.
    sort((a, b) => b.count - a.count).
    slice(0, 5);

    return {
      totalPrompts: prompts.length,
      promptsByCategory,
      promptsByMonth,
      topTags
    };
  } catch (error) {
    console.error('Error generating analytics:', error);
    throw error;
  }
}

// Initialize database on load
window.addEventListener('load', () => {
  console.log('Initializing database on page load...');
  initializeTables().
  then((tableIds) => {
    console.log('Database initialized with tables:', tableIds);
  }).
  catch((error) => {
    console.error('Failed to initialize database:', error);
  });
});