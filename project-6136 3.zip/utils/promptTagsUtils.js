// Utility functions for working with prompt tags

// Get tags for a specific prompt
async function getTagsForPrompt(promptId) {
  try {
    const PROMPT_TAGS_TABLE_ID = 3558; // Fixed ID based on table creation

    // Query the prompt_tags table to get all tag relationships for this prompt
    const queryParams = {
      PageNo: 1,
      PageSize: 100, // Assuming a prompt won't have more than 100 tags
      Filters: [
      {
        name: "prompt_id",
        op: "Equal",
        value: promptId
      }]

    };

    const response = await window.ezsite.apis.tablePage(PROMPT_TAGS_TABLE_ID, queryParams);

    if (response.error) {
      throw new Error(response.error);
    }

    // Extract the tag IDs
    const tagIds = response.data.List.map((relation) => relation.tag_id);

    // Now fetch the actual tag details for these IDs
    const TAGS_TABLE_ID = 3557; // Fixed ID based on table creation

    const tags = [];
    for (const tagId of tagIds) {
      const tagQueryParams = {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: "ID",
          op: "Equal",
          value: tagId
        }]

      };

      const tagResponse = await window.ezsite.apis.tablePage(TAGS_TABLE_ID, tagQueryParams);

      if (tagResponse.error) {
        console.error('Error fetching tag details:', tagResponse.error);
        continue;
      }

      if (tagResponse.data.List.length > 0) {
        tags.push(tagResponse.data.List[0]);
      }
    }

    return tags;
  } catch (error) {
    console.error('Error getting tags for prompt:', error);
    throw error;
  }
}

// Add tags to a prompt
async function addTagsToPrompt(promptId, tagIds) {
  try {
    const PROMPT_TAGS_TABLE_ID = 3558; // Fixed ID based on table creation

    for (const tagId of tagIds) {
      const tagRelation = {
        prompt_id: promptId,
        tag_id: tagId
      };

      const response = await window.ezsite.apis.tableCreate(PROMPT_TAGS_TABLE_ID, tagRelation);

      if (response.error) {
        console.error('Error adding tag to prompt:', response.error);
      }
    }

    return true;
  } catch (error) {
    console.error('Error adding tags to prompt:', error);
    throw error;
  }
}

// Remove a tag from a prompt
async function removeTagFromPrompt(promptId, tagId) {
  try {
    const PROMPT_TAGS_TABLE_ID = 3558; // Fixed ID based on table creation

    // First find the relation entry
    const queryParams = {
      PageNo: 1,
      PageSize: 1,
      Filters: [
      {
        name: "prompt_id",
        op: "Equal",
        value: promptId
      },
      {
        name: "tag_id",
        op: "Equal",
        value: tagId
      }]

    };

    const response = await window.ezsite.apis.tablePage(PROMPT_TAGS_TABLE_ID, queryParams);

    if (response.error) {
      throw new Error(response.error);
    }

    if (response.data.List.length === 0) {
      // Relation not found
      return false;
    }

    // Delete the relation
    const relationId = response.data.List[0].ID;
    const deleteResponse = await window.ezsite.apis.tableDelete(PROMPT_TAGS_TABLE_ID, { ID: relationId });

    if (deleteResponse.error) {
      throw new Error(deleteResponse.error);
    }

    return true;
  } catch (error) {
    console.error('Error removing tag from prompt:', error);
    throw error;
  }
}