// Format date for display
function formatDate(dateString) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(date);
}

// Format time for display
function formatTime(dateString) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  }).format(date);
}

// Format date and time for display
function formatDateTime(dateString) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  }).format(date);
}

// Get time elapsed since date
function timeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);

  let interval = Math.floor(seconds / 31536000);
  if (interval > 1) {
    return `${interval} years ago`;
  } else if (interval === 1) {
    return 'a year ago';
  }

  interval = Math.floor(seconds / 2592000);
  if (interval > 1) {
    return `${interval} months ago`;
  } else if (interval === 1) {
    return 'a month ago';
  }

  interval = Math.floor(seconds / 86400);
  if (interval > 1) {
    return `${interval} days ago`;
  } else if (interval === 1) {
    return 'yesterday';
  }

  interval = Math.floor(seconds / 3600);
  if (interval > 1) {
    return `${interval} hours ago`;
  } else if (interval === 1) {
    return 'an hour ago';
  }

  interval = Math.floor(seconds / 60);
  if (interval > 1) {
    return `${interval} minutes ago`;
  } else if (interval === 1) {
    return 'a minute ago';
  }

  if (seconds < 10) {
    return 'just now';
  }

  return `${Math.floor(seconds)} seconds ago`;
}

// Truncate text to a specific length
function truncateText(text, length = 100) {
  if (!text) return '';
  if (text.length <= length) return text;
  return text.substring(0, length) + '...';
}

// Generate avatar from user name
function getInitials(name) {
  if (!name) return 'U';
  const parts = name.split(' ');
  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase();
  }
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

// Generate random ID
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

// Copy text to clipboard
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).
  catch((err) => console.error('Could not copy text: ', err));
}

// Filter prompts by search term
function filterPromptsBySearch(prompts, searchTerm) {
  if (!searchTerm) return prompts;
  const term = searchTerm.toLowerCase();
  return prompts.filter((prompt) =>
  prompt.title.toLowerCase().includes(term) ||
  prompt.content.toLowerCase().includes(term) ||
  prompt.tags.some((tag) => tag.toLowerCase().includes(term)) ||
  prompt.category.toLowerCase().includes(term)
  );
}

// Filter prompts by category
function filterPromptsByCategory(prompts, category) {
  if (!category) return prompts;
  return prompts.filter((prompt) => prompt.category === category);
}

// Filter prompts by tag
function filterPromptsByTag(prompts, tag) {
  if (!tag) return prompts;
  return prompts.filter((prompt) => prompt.tags.includes(tag));
}

// Sort prompts by date, usage, etc.
function sortPrompts(prompts, sortBy = 'newest') {
  const sorted = [...prompts];

  switch (sortBy) {
    case 'newest':
      return sorted.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    case 'oldest':
      return sorted.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    case 'updated':
      return sorted.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    case 'usage':
      return sorted.sort((a, b) => b.usage - a.usage);
    case 'title':
      return sorted.sort((a, b) => a.title.localeCompare(b.title));
    default:
      return sorted;
  }
}

// Generate random color from a string (consistent color for same string)
function stringToColor(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  let color = '#';
  for (let i = 0; i < 3; i++) {
    const value = hash >> i * 8 & 0xFF;
    color += ('00' + value.toString(16)).substr(-2);
  }
  return color;
}