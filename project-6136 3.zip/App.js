// Main App component

const App = () => {
  // Initialize app with database
  React.useEffect(() => {
    if (window.ezsite && window.ezsite.apis) {
      console.log('App initialized with API connection');
      // We can add any app-level initialization here
    }
  }, []);

  return (
    <React.StrictMode>
      <ThemeProvider>
        <ReactRouterDOM.BrowserRouter>
          <AuthProvider>
            <PromptsProvider>
              <Router />
            </PromptsProvider>
          </AuthProvider>
        </ReactRouterDOM.BrowserRouter>
      </ThemeProvider>
    </React.StrictMode>);

};