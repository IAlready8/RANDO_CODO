const { createContext, useState, useEffect, useContext } = React;

// Create Prompts Context
const PromptsContext = createContext();

function PromptsProvider({ children }) {
  const [prompts, setPrompts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const { currentUser } = useAuth();

  // Load prompts, categories, and tags on mount or when user changes
  useEffect(() => {
    if (currentUser) {
      loadPrompts();
      loadCategories();
      loadTags();
    } else {
      setPrompts([]);
      setCategories([]);
      setTags([]);
      setLoading(false);
    }
  }, [currentUser]);

  // Load user's prompts from database
  const loadPrompts = async () => {
    try {
      setLoading(true);

      if (window.ezsite && window.ezsite.apis) {
        const result = await fetchPrompts(currentUser.id);
        // Convert DB format to app format
        const formattedPrompts = result.prompts.map((p) => ({
          id: p.ID.toString(),
          title: p.title,
          content: p.content,
          category: p.category_id, // We'll need to resolve this with category name later
          isPrivate: false,
          usage: p.usage_count || 0,
          isFavorite: p.is_favorite || false,
          createdAt: p.created_at,
          updatedAt: p.updated_at,
          userId: p.user_id,
          tags: [] // Tags will be loaded separately
        }));
        setPrompts(formattedPrompts || []);
      } else {
        // Fallback to localStorage if API not available
        const savedPrompts = JSON.parse(localStorage.getItem(`prompts_${currentUser.id}`) || '[]');
        setPrompts(savedPrompts);
      }
    } catch (error) {
      setError('Failed to load prompts');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Load user's categories from database
  const loadCategories = async () => {
    try {
      if (window.ezsite && window.ezsite.apis) {
        const result = await fetchCategories(currentUser.id);
        setCategories(result || []);
      } else {
        // Fallback to localStorage if API not available
        const savedCategories = JSON.parse(localStorage.getItem(`categories_${currentUser.id}`) || '[]');
        setCategories(savedCategories);
      }
    } catch (error) {
      setError('Failed to load categories');
      console.error(error);
    }
  };

  // Load user's tags from database
  const loadTags = async () => {
    try {
      if (window.ezsite && window.ezsite.apis) {
        const result = await fetchTags(currentUser.id);
        setTags(result || []);
      } else {
        // Fallback to localStorage if API not available
        const savedTags = JSON.parse(localStorage.getItem(`tags_${currentUser.id}`) || '[]');
        setTags(savedTags);
      }
    } catch (error) {
      setError('Failed to load tags');
      console.error(error);
    }
  };

  // Add a new prompt
  const addPrompt = async (promptText) => {
    try {
      setLoading(true);
      setError('');

      // Analyze prompt with API
      const { title, suggestedTags, category } = await analyzePrompt(promptText);

      if (window.ezsite && window.ezsite.apis) {
        // Check if category exists, create if not
        let categoryId;
        const existingCategory = categories.find((c) => c.name === category);

        if (existingCategory) {
          categoryId = existingCategory.id;
        } else {
          // Create new category in database
          const newCategory = await createCategory({
            userId: currentUser.id,
            name: category,
            description: `Category for ${category} prompts`,
            color: getRandomColor()
          });
          categoryId = newCategory.ID;

          // Add to local categories
          const categoryObj = {
            id: newCategory.ID.toString(),
            name: category,
            count: 1,
            color: newCategory.color
          };
          setCategories([...categories, categoryObj]);
        }

        // Create tags if they don't exist
        const tagIds = [];
        for (const tagName of suggestedTags) {
          const existingTag = tags.find((t) => t.name === tagName);
          if (existingTag) {
            tagIds.push(existingTag.id);
          } else {
            // Create new tag in database
            const newTag = await createTag({
              userId: currentUser.id,
              name: tagName
            });
            tagIds.push(newTag.ID);

            // Add to local tags
            setTags([...tags, {
              id: newTag.ID.toString(),
              name: tagName,
              count: 1
            }]);
          }
        }

        // Create prompt in database
        const promptData = {
          userId: currentUser.id,
          title: title,
          content: promptText,
          categoryId: categoryId,
          tags: tagIds
        };

        const createdPrompt = await createPrompt(promptData);

        // Create local prompt object
        const newPrompt = {
          id: createdPrompt.ID.toString(),
          title,
          content: promptText,
          tags: suggestedTags,
          category,
          categoryId,
          createdAt: createdPrompt.created_at,
          updatedAt: createdPrompt.updated_at,
          userId: currentUser.id,
          usage: 0
        };

        // Add prompt to the list
        const updatedPrompts = [newPrompt, ...prompts];
        setPrompts(updatedPrompts);

        return newPrompt;
      } else {
        // Fallback to localStorage if API not available
        // Create new prompt object
        const newPrompt = {
          id: Date.now().toString(),
          title,
          content: promptText,
          tags: suggestedTags,
          category,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          userId: currentUser.id,
          usage: 0
        };

        // Add prompt to the list
        const updatedPrompts = [newPrompt, ...prompts];
        setPrompts(updatedPrompts);
        localStorage.setItem(`prompts_${currentUser.id}`, JSON.stringify(updatedPrompts));

        // Update tags and categories
        updateTagsAndCategories(suggestedTags, category);

        return newPrompt;
      }
    } catch (error) {
      setError('Failed to add prompt');
      console.error(error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Helper function to generate a random color for categories
  const getRandomColor = () => {
    const colors = ['#9333ea', '#3b82f6', '#ef4444', '#22c55e', '#f97316', '#14b8a6', '#8b5cf6', '#ec4899'];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  // Update an existing prompt
  const updatePrompt = async (id, updates) => {
    try {
      setLoading(true);
      setError('');

      // Find prompt
      const promptIndex = prompts.findIndex((p) => p.id === id);
      if (promptIndex === -1) {
        throw new Error('Prompt not found');
      }

      // If content is changed, analyze it
      let updatedTags = prompts[promptIndex].tags;
      let updatedCategory = prompts[promptIndex].category;

      if (updates.content && updates.content !== prompts[promptIndex].content) {
        const { title, suggestedTags, category } = await analyzePrompt(updates.content);
        updatedTags = updates.tags || suggestedTags;
        updatedCategory = updates.category || category;
        updates.title = updates.title || title;
      }

      // Update prompt
      const updatedPrompt = {
        ...prompts[promptIndex],
        ...updates,
        tags: updatedTags,
        category: updatedCategory,
        updatedAt: new Date().toISOString()
      };

      const updatedPrompts = [...prompts];
      updatedPrompts[promptIndex] = updatedPrompt;

      setPrompts(updatedPrompts);
      localStorage.setItem(`prompts_${currentUser.id}`, JSON.stringify(updatedPrompts));

      // Update tags and categories
      updateTagsAndCategories(updatedTags, updatedCategory);

      return updatedPrompt;
    } catch (error) {
      setError('Failed to update prompt');
      console.error(error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Delete a prompt
  const deletePrompt = async (id) => {
    try {
      setLoading(true);
      setError('');

      if (window.ezsite && window.ezsite.apis) {
        // Delete from database
        await deletePrompt(id);

        // Update local state
        const updatedPrompts = prompts.filter((p) => p.id !== id);
        setPrompts(updatedPrompts);

        // Recalculate tags and categories
        await recalculateTagsAndCategories(updatedPrompts);
      } else {
        // Fallback to localStorage
        const updatedPrompts = prompts.filter((p) => p.id !== id);
        setPrompts(updatedPrompts);
        localStorage.setItem(`prompts_${currentUser.id}`, JSON.stringify(updatedPrompts));

        // Recalculate tags and categories
        recalculateTagsAndCategories(updatedPrompts);
      }

      return true;
    } catch (error) {
      setError('Failed to delete prompt');
      console.error(error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Update tags and categories based on new prompt
  const updateTagsAndCategories = (newTags, newCategory) => {
    // Update tags
    const updatedTags = [...tags];
    newTags.forEach((tag) => {
      const existingTag = updatedTags.find((t) => t.name === tag);
      if (existingTag) {
        existingTag.count++;
      } else {
        updatedTags.push({ name: tag, count: 1 });
      }
    });
    setTags(updatedTags);
    localStorage.setItem(`tags_${currentUser.id}`, JSON.stringify(updatedTags));

    // Update categories
    const updatedCategories = [...categories];
    const existingCategory = updatedCategories.find((c) => c.name === newCategory);
    if (existingCategory) {
      existingCategory.count++;
    } else {
      updatedCategories.push({ name: newCategory, count: 1 });
    }
    setCategories(updatedCategories);
    localStorage.setItem(`categories_${currentUser.id}`, JSON.stringify(updatedCategories));
  };

  // Recalculate tags and categories after deletion
  const recalculateTagsAndCategories = (updatedPrompts) => {
    // Reset counts
    const tagCounts = {};
    const categoryCounts = {};

    // Count occurrences
    updatedPrompts.forEach((prompt) => {
      // Count tags
      prompt.tags.forEach((tag) => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });

      // Count categories
      categoryCounts[prompt.category] = (categoryCounts[prompt.category] || 0) + 1;
    });

    // Update tags
    const updatedTags = Object.keys(tagCounts).map((name) => ({
      name,
      count: tagCounts[name]
    }));
    setTags(updatedTags);
    localStorage.setItem(`tags_${currentUser.id}`, JSON.stringify(updatedTags));

    // Update categories
    const updatedCategories = Object.keys(categoryCounts).map((name) => ({
      name,
      count: categoryCounts[name]
    }));
    setCategories(updatedCategories);
    localStorage.setItem(`categories_${currentUser.id}`, JSON.stringify(updatedCategories));
  };

  // Analyze prompt using the OpenAI API (mock for now)
  const analyzePrompt = async (promptText) => {
    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Generate a title from the first few words
      const title = promptText.split(' ').slice(0, 5).join(' ') + (
      promptText.split(' ').length > 5 ? '...' : '');

      // Generate random tags based on content
      const allPossibleTags = [
      'creative', 'technical', 'business', 'marketing',
      'writing', 'coding', 'data', 'design', 'analysis',
      'research', 'storytelling', 'productivity'];


      // Extract some random tags based on content length
      const numTags = Math.min(3, Math.floor(promptText.length / 50) + 1);
      const suggestedTags = [];

      for (let i = 0; i < numTags; i++) {
        const randomTag = allPossibleTags[Math.floor(Math.random() * allPossibleTags.length)];
        if (!suggestedTags.includes(randomTag)) {
          suggestedTags.push(randomTag);
        }
      }

      // Determine category based on content
      const allCategories = [
      'General', 'Creative Writing', 'Technical', 'Business',
      'Marketing', 'Personal', 'Research', 'Education'];

      const category = allCategories[Math.floor(Math.random() * allCategories.length)];

      return { title, suggestedTags, category };
    } catch (error) {
      console.error('Error analyzing prompt:', error);
      // Default values if analysis fails
      return {
        title: 'New Prompt',
        suggestedTags: ['general'],
        category: 'General'
      };
    }
  };

  // Get analytics data
  const getAnalytics = () => {
    if (!prompts.length) {
      return {
        totalPrompts: 0,
        promptsByCategory: [],
        promptsByMonth: [],
        topTags: []
      };
    }

    // Count prompts by category
    const categoryData = {};
    categories.forEach((cat) => {
      categoryData[cat.name] = cat.count;
    });
    const promptsByCategory = Object.keys(categoryData).map((name) => ({
      name,
      value: categoryData[name]
    }));

    // Count prompts by month
    const monthData = {};
    prompts.forEach((prompt) => {
      const date = new Date(prompt.createdAt);
      const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
      monthData[monthYear] = (monthData[monthYear] || 0) + 1;
    });

    const promptsByMonth = Object.keys(monthData).
    sort((a, b) => {
      const [aMonth, aYear] = a.split('/').map(Number);
      const [bMonth, bYear] = b.split('/').map(Number);
      return aYear * 12 + aMonth - (bYear * 12 + bMonth);
    }).
    map((monthYear) => ({
      month: monthYear,
      count: monthData[monthYear]
    }));

    // Get top tags
    const topTags = [...tags].
    sort((a, b) => b.count - a.count).
    slice(0, 5);

    return {
      totalPrompts: prompts.length,
      promptsByCategory,
      promptsByMonth,
      topTags
    };
  };

  const value = {
    prompts,
    categories,
    tags,
    loading,
    error,
    addPrompt,
    updatePrompt,
    deletePrompt,
    getAnalytics
  };

  return (
    <PromptsContext.Provider value={value}>
      {children}
    </PromptsContext.Provider>);

}

// Custom hook to use prompts context
function usePrompts() {
  const context = useContext(PromptsContext);
  if (context === undefined) {
    throw new Error('usePrompts must be used within a PromptsProvider');
  }
  return context;
}