const { createContext, useState, useEffect, useContext } = React;

// Create Authentication Context
const AuthContext = createContext();

function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Check if user is logged in on mount
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      setCurrentUser(JSON.parse(user));
    }
    setLoading(false);
  }, []);

  // Register a new user
  const register = async (email, password, name) => {
    try {
      setLoading(true);
      setError('');

      if (window.ezsite && window.ezsite.apis) {
        // Use the real API
        const response = await window.ezsite.apis.register({
          email,
          password,
          name
        });

        if (response.error) {
          throw new Error(response.error);
        }

        // We don't set the current user here as the user needs to verify their email
        return { success: true };
      } else {
        // Fallback to local storage for development
        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Check if user already exists
        const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
        const userExists = existingUsers.find((user) => user.email === email);

        if (userExists) {
          throw new Error('User with this email already exists');
        }

        // Create new user
        const newUser = {
          id: Date.now().toString(),
          email,
          name,
          password, // In a real app, you would NEVER store passwords in localStorage
          createdAt: new Date().toISOString()
        };

        // Add user to users list
        existingUsers.push(newUser);
        localStorage.setItem('users', JSON.stringify(existingUsers));

        // Set current user (without password)
        const { password: _, ...userWithoutPassword } = newUser;
        setCurrentUser(userWithoutPassword);
        localStorage.setItem('user', JSON.stringify(userWithoutPassword));

        return userWithoutPassword;
      }
    } catch (error) {
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Login user
  const login = async (email, password) => {
    try {
      setLoading(true);
      setError('');

      if (window.ezsite && window.ezsite.apis) {
        // Use the real API
        const response = await window.ezsite.apis.login({
          email,
          password
        });

        if (response.error) {
          throw new Error(response.error);
        }

        // Get user info after successful login
        const userInfoResponse = await window.ezsite.apis.getUserInfo();

        if (userInfoResponse.error) {
          throw new Error(userInfoResponse.error);
        }

        const userInfo = userInfoResponse.data;

        // Set current user
        setCurrentUser({
          id: userInfo.ID,
          name: userInfo.Name,
          email: userInfo.Email,
          createdAt: userInfo.CreateTime
        });

        // Store user in localStorage for persistence
        localStorage.setItem('user', JSON.stringify({
          id: userInfo.ID,
          name: userInfo.Name,
          email: userInfo.Email,
          createdAt: userInfo.CreateTime
        }));

        return userInfo;
      } else {
        // Fallback to local storage for development
        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Check if user exists
        const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
        const user = existingUsers.find((user) => user.email === email && user.password === password);

        if (!user) {
          throw new Error('Invalid email or password');
        }

        // Set current user (without password)
        const { password: _, ...userWithoutPassword } = user;
        setCurrentUser(userWithoutPassword);
        localStorage.setItem('user', JSON.stringify(userWithoutPassword));

        return userWithoutPassword;
      }
    } catch (error) {
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout user
  const logout = async () => {
    try {
      if (window.ezsite && window.ezsite.apis) {
        // Use the real API
        const response = await window.ezsite.apis.logout();

        if (response.error) {
          console.error('Logout error:', response.error);
        }
      }

      // Always clear local state regardless of API result
      localStorage.removeItem('user');
      setCurrentUser(null);
    } catch (error) {
      console.error('Logout error:', error);
      // Still clear local state even if API call fails
      localStorage.removeItem('user');
      setCurrentUser(null);
    }
  };

  // Update user profile
  const updateProfile = async (updates) => {
    try {
      setLoading(true);
      setError('');

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Get existing users
      const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const userIndex = existingUsers.findIndex((user) => user.id === currentUser.id);

      if (userIndex === -1) {
        throw new Error('User not found');
      }

      // Update user
      const updatedUser = { ...existingUsers[userIndex], ...updates };
      existingUsers[userIndex] = updatedUser;

      // Save updated users
      localStorage.setItem('users', JSON.stringify(existingUsers));

      // Update current user
      const { password: _, ...userWithoutPassword } = updatedUser;
      setCurrentUser(userWithoutPassword);
      localStorage.setItem('user', JSON.stringify(userWithoutPassword));

      return userWithoutPassword;
    } catch (error) {
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    currentUser,
    loading,
    error,
    register,
    login,
    logout,
    updateProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>);

}

// Custom hook to use auth context
function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}