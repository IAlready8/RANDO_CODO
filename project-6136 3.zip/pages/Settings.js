// User settings page

const Settings = () => {
  const { useState } = React;
  const { currentUser, updateProfile, logout } = useAuth();
  const { toggleDarkMode, darkMode } = useTheme();
  const navigate = ReactRouterDOM.useNavigate();

  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [isApiKeyVisible, setIsApiKeyVisible] = useState(false);
  const [showDeleteDataModal, setShowDeleteDataModal] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  // Handle profile update
  const handleProfileUpdate = async (e) => {
    e.preventDefault();

    if (!name || !email) {
      setError('Name and email are required');
      return;
    }

    try {
      setLoading(true);
      setError('');

      await updateProfile({ name, email });

      setSuccess('Profile updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError(`Failed to update profile: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle password update
  const handlePasswordUpdate = async (e) => {
    e.preventDefault();

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('All password fields are required');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // In a real app, we would validate the current password
      // For this demo, we'll just update it
      await updateProfile({ password: newPassword });

      setSuccess('Password updated successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');

      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError(`Failed to update password: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle API key update
  const handleApiKeyUpdate = () => {
    try {
      setLoading(true);
      setError('');

      // Simulate API call
      setTimeout(() => {
        setSuccess('API key updated successfully');
        setLoading(false);
        setTimeout(() => setSuccess(''), 3000);
      }, 1000);
    } catch (error) {
      setError('Failed to update API key');
      setLoading(false);
    }
  };

  // Handle data export
  const handleExportData = () => {
    try {
      // Create sample export data
      const exportData = {
        user: {
          name: currentUser?.name,
          email: currentUser?.email
        },
        settings: {
          darkMode
        },
        prompts: [] // In a real app, we would include actual prompts data
      };

      // Convert to JSON string
      const jsonData = JSON.stringify(exportData, null, 2);

      // Create a blob and download link
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `promptmaster_export_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();

      // Clean up
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 100);

      setSuccess('Data exported successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError('Failed to export data');
    }
  };

  // Handle account exit
  const handleExit = () => {
    setShowExitModal(true);
  };

  // Confirm exit and go back to dashboard
  const confirmExit = () => {
    navigate('/');
  };

  // Handle delete all data
  const handleDeleteAllData = () => {
    setShowDeleteDataModal(true);
  };

  // Confirm delete all data
  const confirmDeleteAllData = () => {
    try {
      setLoading(true);

      // Simulate API call to delete data
      setTimeout(() => {
        setSuccess('All data deleted successfully');
        setLoading(false);
        setTimeout(() => {
          setSuccess('');
          navigate('/');
        }, 2000);
      }, 1500);
    } catch (error) {
      setError('Failed to delete data');
      setLoading(false);
    }
  };

  return (
    <div className="dashboard-container" data-id="qfyvnmtml" data-path="pages/Settings.js">
      <div className="dashboard-header" data-id="i8fejdh7i" data-path="pages/Settings.js">
        <div className="flex items-center" data-id="k6oz61xjj" data-path="pages/Settings.js">
          <button
            className="mr-3 text-gray-400 hover:text-white"
            onClick={() => navigate('/')} data-id="s30ll7nu9" data-path="pages/Settings.js">

            <i className="fas fa-arrow-left text-xl" data-id="bo281c3mz" data-path="pages/Settings.js"></i>
          </button>
          <h1 className="dashboard-title" data-id="9a9oz8w6v" data-path="pages/Settings.js">Settings</h1>
        </div>
        <div className="dashboard-actions" data-id="we2ivc6i0" data-path="pages/Settings.js">
          <Button
            variant="outline"
            onClick={handleExit}
            icon={<i className="fas fa-sign-out-alt" data-id="re9hbuq6q" data-path="pages/Settings.js"></i>}>
            Exit
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-id="tb99ovsib" data-path="pages/Settings.js">
        {/* Profile Settings */}
        <div className="lg:col-span-2" data-id="gn846m5gm" data-path="pages/Settings.js">
          <Card
            title="Profile Settings"
            className="mb-6">
            <form onSubmit={handleProfileUpdate} data-id="s93m0e7c7" data-path="pages/Settings.js">
              <div className="mb-4" data-id="odcb91qcz" data-path="pages/Settings.js">
                <label className="block text-gray-300 mb-1" htmlFor="name" data-id="ab6oeo52e" data-path="pages/Settings.js">Full Name</label>
                <input
                  id="name"
                  type="text"
                  className="auth-input"
                  placeholder="Enter your full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={loading} data-id="1f0lrb8c3" data-path="pages/Settings.js" />
              </div>
              
              <div className="mb-4" data-id="ohlxuxbju" data-path="pages/Settings.js">
                <label className="block text-gray-300 mb-1" htmlFor="email" data-id="dxr7sbfog" data-path="pages/Settings.js">Email</label>
                <input
                  id="email"
                  type="email"
                  className="auth-input"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading} data-id="f6ntefqc8" data-path="pages/Settings.js" />
              </div>
              
              <div className="flex justify-between" data-id="fg1uob4a7" data-path="pages/Settings.js">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/')}
                  icon={<i className="fas fa-times" data-id="dc0y4yeb2" data-path="pages/Settings.js"></i>}>
                  Cancel
                </Button>
                
                <Button
                  type="submit"
                  loading={loading}
                  disabled={loading}
                  icon={<i className="fas fa-save" data-id="v4xlhi57m" data-path="pages/Settings.js"></i>}>
                  Save Profile
                </Button>
              </div>
            </form>
          </Card>
          
          {/* Password Settings */}
          <Card
            title="Change Password"
            className="mb-6">
            <form onSubmit={handlePasswordUpdate} data-id="zyu5ebt8a" data-path="pages/Settings.js">
              <div className="mb-4" data-id="u5syqqhxg" data-path="pages/Settings.js">
                <label className="block text-gray-300 mb-1" htmlFor="current-password" data-id="vpa5efu76" data-path="pages/Settings.js">Current Password</label>
                <input
                  id="current-password"
                  type="password"
                  className="auth-input"
                  placeholder="Enter your current password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  disabled={loading} data-id="5uact28j2" data-path="pages/Settings.js" />
              </div>
              
              <div className="mb-4" data-id="a9mhzqsko" data-path="pages/Settings.js">
                <label className="block text-gray-300 mb-1" htmlFor="new-password" data-id="xppnfh748" data-path="pages/Settings.js">New Password</label>
                <input
                  id="new-password"
                  type="password"
                  className="auth-input"
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  disabled={loading} data-id="1ms89f6wi" data-path="pages/Settings.js" />
              </div>
              
              <div className="mb-4" data-id="etmmxi9iu" data-path="pages/Settings.js">
                <label className="block text-gray-300 mb-1" htmlFor="confirm-password" data-id="j8o5h9maf" data-path="pages/Settings.js">Confirm New Password</label>
                <input
                  id="confirm-password"
                  type="password"
                  className="auth-input"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={loading} data-id="jjxznpi2a" data-path="pages/Settings.js" />
              </div>
              
              <div className="flex justify-between" data-id="d5pf3pwq6" data-path="pages/Settings.js">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setCurrentPassword('');
                    setNewPassword('');
                    setConfirmPassword('');
                  }}
                  icon={<i className="fas fa-undo" data-id="2idcgb9du" data-path="pages/Settings.js"></i>}>
                  Reset Form
                </Button>
                
                <Button
                  type="submit"
                  loading={loading}
                  disabled={loading}
                  icon={<i className="fas fa-save" data-id="f77r3sqo8" data-path="pages/Settings.js"></i>}>
                  Save Password
                </Button>
              </div>
            </form>
          </Card>
          
          {success &&
          <div className="bg-success bg-opacity-20 text-success p-4 rounded-lg mb-6" data-id="u59maspkp" data-path="pages/Settings.js">
              <i className="fas fa-check-circle mr-2" data-id="2efd2dxco" data-path="pages/Settings.js"></i> {success}
            </div>
          }
          
          {error &&
          <div className="bg-error bg-opacity-20 text-error p-4 rounded-lg mb-6" data-id="ckoam06b0" data-path="pages/Settings.js">
              <i className="fas fa-exclamation-circle mr-2" data-id="i8yn234f2" data-path="pages/Settings.js"></i> {error}
            </div>
          }
        </div>
        
        {/* Sidebar Settings */}
        <div data-id="8elq3nvic" data-path="pages/Settings.js">
          {/* Theme Settings */}
          <Card
            title="Appearance"
            className="mb-6">
            <div className="p-4 flex justify-between items-center" data-id="ftc2z000y" data-path="pages/Settings.js">
              <div data-id="38efmataw" data-path="pages/Settings.js">
                <h3 className="font-medium" data-id="72xziwqzv" data-path="pages/Settings.js">Dark Mode</h3>
                <p className="text-sm text-gray-400" data-id="kxmwckg64" data-path="pages/Settings.js">Toggle between dark and light mode</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer" data-id="cgcw6ckcm" data-path="pages/Settings.js">
                <input
                  type="checkbox"
                  checked={darkMode}
                  onChange={toggleDarkMode}
                  className="sr-only peer" data-id="c9y64pgk2" data-path="pages/Settings.js" />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary" data-id="tb2fea926" data-path="pages/Settings.js"></div>
              </label>
            </div>
            
            <div className="border-t border-gray-700 p-4 flex justify-end" data-id="rnbpjqds0" data-path="pages/Settings.js">
              <Button
                variant="primary"
                size="sm"
                icon={<i className="fas fa-save" data-id="08pdc9eyr" data-path="pages/Settings.js"></i>}>
                Save Changes
              </Button>
            </div>
          </Card>
          
          {/* API Settings */}
          <Card
            title="API Integration"
            className="mb-6">
            <div className="p-4" data-id="ss2ang1sf" data-path="pages/Settings.js">
              <h3 className="font-medium mb-2" data-id="qx41guwtd" data-path="pages/Settings.js">OpenAI API Key</h3>
              <div className="mb-4 relative" data-id="wko1u6aac" data-path="pages/Settings.js">
                <input
                  type={isApiKeyVisible ? "text" : "password"}
                  className="auth-input pr-10"
                  placeholder="Enter your OpenAI API key"
                  value={apiKey || "sk-••••••••••••••••••••••••••••••••"}
                  onChange={(e) => setApiKey(e.target.value)} data-id="5z57kmb4g" data-path="pages/Settings.js" />

                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                  onClick={() => setIsApiKeyVisible(!isApiKeyVisible)} data-id="eg75itoif" data-path="pages/Settings.js">

                  <i className={`fas ${isApiKeyVisible ? 'fa-eye-slash' : 'fa-eye'}`} data-id="8aq3y5lh9" data-path="pages/Settings.js"></i>
                </button>
              </div>
              <Button
                variant="primary"
                fullWidth
                onClick={handleApiKeyUpdate}
                loading={loading}
                icon={<i className="fas fa-save" data-id="786nltgvu" data-path="pages/Settings.js"></i>}>
                Save API Key
              </Button>
            </div>
          </Card>
          
          {/* Data Export */}
          <Card
            title="Data Management">
            <div className="p-4" data-id="vi1z5exf2" data-path="pages/Settings.js">
              <div className="mb-4" data-id="7lyf17hqp" data-path="pages/Settings.js">
                <h3 className="font-medium mb-1" data-id="qjqxq78zi" data-path="pages/Settings.js">Export Data</h3>
                <p className="text-sm text-gray-400 mb-2" data-id="mwbkrk3zk" data-path="pages/Settings.js">Download all your prompts and settings</p>
                <Button
                  variant="primary"
                  fullWidth
                  onClick={handleExportData}
                  icon={<i className="fas fa-download" data-id="qa0njt8fo" data-path="pages/Settings.js"></i>}>
                  Export as JSON
                </Button>
              </div>
              
              <div data-id="stnzcosnl" data-path="pages/Settings.js">
                <h3 className="font-medium mb-1 text-error" data-id="7tpg12x5o" data-path="pages/Settings.js">Danger Zone</h3>
                <p className="text-sm text-gray-400 mb-2" data-id="99u4ivw09" data-path="pages/Settings.js">Delete all your data from the system</p>
                <Button
                  variant="danger"
                  fullWidth
                  onClick={handleDeleteAllData}
                  icon={<i className="fas fa-trash-alt" data-id="425gpttjf" data-path="pages/Settings.js"></i>}>
                  Delete All Data
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Delete Data Confirmation Modal */}
      <ConfirmModal
        isOpen={showDeleteDataModal}
        onClose={() => setShowDeleteDataModal(false)}
        onConfirm={confirmDeleteAllData}
        title="Delete All Data"
        message="Are you sure you want to delete all your data? This action cannot be undone and will remove all your prompts, categories, and tags."
        confirmText="Delete Everything"
        cancelText="Cancel"
        variant="danger" />

      
      {/* Exit Confirmation Modal */}
      <ConfirmModal
        isOpen={showExitModal}
        onClose={() => setShowExitModal(false)}
        onConfirm={confirmExit}
        title="Exit Settings"
        message="Are you sure you want to exit? Any unsaved changes will be lost."
        confirmText="Exit"
        cancelText="Stay Here"
        variant="primary" />

    </div>);

};