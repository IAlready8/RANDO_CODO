// Reset Password page

const ResetPassword = () => {
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [error, setError] = React.useState('');
  const [success, setSuccess] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const navigate = ReactRouterDOM.useNavigate();
  const location = ReactRouterDOM.useLocation();

  // Get token from query string
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get('token');

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate input
    if (!password) {
      setError('Password is required');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (!token) {
      setError('Invalid or missing reset token');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Call API to reset password
      const response = await window.ezsite.apis.resetPassword({
        token,
        password
      });

      if (response.error) {
        throw new Error(response.error);
      }

      // Show success message
      setSuccess(true);

      // Redirect to login page after 3 seconds
      setTimeout(() => {
        navigate('/auth');
      }, 3000);

    } catch (error) {
      setError(error.message || 'Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-dark" data-id="nqpqnrqx0" data-path="pages/ResetPassword.js">
      <div className="w-full max-w-md p-6 bg-darklight rounded-lg shadow-lg" data-id="gmks71oz5" data-path="pages/ResetPassword.js">
        <h2 className="text-2xl font-bold text-white mb-6 text-center" data-id="p3ls3yhta" data-path="pages/ResetPassword.js">Reset Password</h2>
        
        {success ?
        <div className="bg-green-800 text-white p-4 rounded mb-4" data-id="iupt5gie4" data-path="pages/ResetPassword.js">
            <p data-id="gh2qytyyq" data-path="pages/ResetPassword.js">Password has been reset successfully!</p>
            <p className="mt-2" data-id="bb94f66fp" data-path="pages/ResetPassword.js">Redirecting to login page...</p>
          </div> :

        <form onSubmit={handleSubmit} data-id="vdd4mbfj1" data-path="pages/ResetPassword.js">
            {error &&
          <div className="bg-red-800 text-white p-4 rounded mb-4" data-id="bttest3bx" data-path="pages/ResetPassword.js">
                {error}
              </div>
          }
            
            {!token &&
          <div className="bg-yellow-700 text-white p-4 rounded mb-4" data-id="nk4ld7l0j" data-path="pages/ResetPassword.js">
                Invalid or missing reset token. Please check your reset link.
              </div>
          }
            
            <div className="mb-4" data-id="h7axd025p" data-path="pages/ResetPassword.js">
              <label className="block text-white text-sm font-bold mb-2" htmlFor="password" data-id="2ic5t44jf" data-path="pages/ResetPassword.js">
                New Password
              </label>
              <input
              id="password"
              type="password"
              className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              placeholder="Enter new password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading || !token} data-id="h3yv6xwm2" data-path="pages/ResetPassword.js" />

            </div>
            
            <div className="mb-6" data-id="ruguvewif" data-path="pages/ResetPassword.js">
              <label className="block text-white text-sm font-bold mb-2" htmlFor="confirmPassword" data-id="z1l1y6ltc" data-path="pages/ResetPassword.js">
                Confirm Password
              </label>
              <input
              id="confirmPassword"
              type="password"
              className="w-full px-3 py-2 bg-gray-800 text-white rounded"
              placeholder="Confirm password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              disabled={loading || !token} data-id="rrt0u9hj6" data-path="pages/ResetPassword.js" />

            </div>
            
            <Button
            className="w-full"
            type="submit"
            disabled={loading || !token}>
              {loading ? 'Resetting...' : 'Reset Password'}
            </Button>
            
            <div className="mt-4 text-center" data-id="3f8bcwj8p" data-path="pages/ResetPassword.js">
              <a
              href="/auth"
              className="text-primary hover:underline" data-id="bumgprnx8" data-path="pages/ResetPassword.js">
                Back to Login
              </a>
            </div>
          </form>
        }
      </div>
    </div>);

};