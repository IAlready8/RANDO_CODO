// Home page / Dashboard

const Home = () => {
  const { useState, useEffect } = React;
  const { prompts, loading, getAnalytics } = usePrompts();
  const navigate = ReactRouterDOM.useNavigate();

  const [stats, setStats] = useState({
    totalPrompts: 0,
    topTags: [],
    promptsByCategory: []
  });
  const [saveState, setSaveState] = useState('idle'); // idle, saving, success, error
  const [showSaveMessage, setShowSaveMessage] = useState(false);

  // Load analytics data
  useEffect(() => {
    const analytics = getAnalytics();
    setStats(analytics);
  }, [prompts]);

  // Handle manual save
  const handleManualSave = () => {
    setSaveState('saving');

    // Simulate saving
    setTimeout(() => {
      setSaveState('success');
      setShowSaveMessage(true);

      // Hide success message after 3 seconds
      setTimeout(() => {
        setShowSaveMessage(false);
        setSaveState('idle');
      }, 3000);
    }, 1000);
  };

  return (
    <div className="dashboard-container" data-id="2yv1hmeob" data-path="pages/Home.js">
      <div className="dashboard-header" data-id="t328ivu2i" data-path="pages/Home.js">
        <h1 className="dashboard-title" data-id="d8xo1yk54" data-path="pages/Home.js">Dashboard</h1>
        <div className="dashboard-actions flex gap-2" data-id="z6xmlhjed" data-path="pages/Home.js">
          <Button
            variant="outline"
            size="md"
            onClick={handleManualSave}
            loading={saveState === 'saving'}
            disabled={saveState === 'saving'}
            icon={<i className="fas fa-save" data-id="r8bygipjq" data-path="pages/Home.js"></i>}>
            {saveState === 'success' ? 'Saved' : 'Save'}
          </Button>
          
          <Button
            variant="primary"
            size="md"
            icon={<i className="fas fa-plus" data-id="b2d7lgehj" data-path="pages/Home.js"></i>}
            onClick={() => navigate('/new-prompt')}>
            New Prompt
          </Button>
        </div>
      </div>
      
      {/* Save message */}
      {showSaveMessage &&
      <div className="bg-success bg-opacity-20 text-success p-3 rounded-lg mb-4 flex items-center justify-between" data-id="0eyk6f3uq" data-path="pages/Home.js">
          <div data-id="wqas2yna1" data-path="pages/Home.js">
            <i className="fas fa-check-circle mr-2" data-id="0xs1ylfub" data-path="pages/Home.js"></i> 
            All changes have been saved successfully
          </div>
          <button
          className="text-success hover:text-success-dark"
          onClick={() => setShowSaveMessage(false)} data-id="jyr7wjkyy" data-path="pages/Home.js">

            <i className="fas fa-times" data-id="3yxdn06xz" data-path="pages/Home.js"></i>
          </button>
        </div>
      }
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6" data-id="yc5g73li8" data-path="pages/Home.js">
        <StatsCard
          title="Total Prompts"
          value={stats.totalPrompts}
          icon={<i className="fas fa-file-alt" data-id="2xxmn7di9" data-path="pages/Home.js"></i>} />
        
        <StatsCard
          title="Top Category"
          value={stats.promptsByCategory.length > 0 ? stats.promptsByCategory[0].name : 'N/A'}
          icon={<i className="fas fa-folder" data-id="kksrxq9wf" data-path="pages/Home.js"></i>} />
        
        <StatsCard
          title="Top Tag"
          value={stats.topTags.length > 0 ? stats.topTags[0].name : 'N/A'}
          icon={<i className="fas fa-tag" data-id="d25zfc10i" data-path="pages/Home.js"></i>} />
        
        <StatsCard
          title="This Month"
          value={stats.promptsByMonth && stats.promptsByMonth.length > 0 ?
          stats.promptsByMonth[stats.promptsByMonth.length - 1].count :
          0}
          change="20% increase"
          isPositive={true}
          icon={<i className="fas fa-chart-line" data-id="ug3dyds58" data-path="pages/Home.js"></i>} />
      </div>
      
      {/* Prompt Input Section */}
      <Card
        title="Create New Prompt"
        className="mb-6"
        icon={<i className="fas fa-magic" data-id="b82rdmqdb" data-path="pages/Home.js"></i>}>
        <PromptInput />
      </Card>
      
      {/* Recent Prompts and Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6" data-id="jowcfs631" data-path="pages/Home.js">
        <div className="lg:col-span-2" data-id="50kix473f" data-path="pages/Home.js">
          <Card
            title="Recent Prompts"
            action={
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/prompts')}>
                View All
              </Button>
            }>
            <PromptList
              prompts={prompts}
              loading={loading}
              limit={5}
              showFilters={false} />
          </Card>
        </div>
        
        <div data-id="gfeb17vfe" data-path="pages/Home.js">
          <Card
            title="Categories"
            action={
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/categories')}>
                View All
              </Button>
            }>
            {stats.promptsByCategory.length > 0 ?
            <PieChart
              data={stats.promptsByCategory.slice(0, 5)}
              labelKey="name"
              valueKey="value" /> :
            <div className="text-center py-4 text-gray-400" data-id="lz7xwp90y" data-path="pages/Home.js">
                No categories found
              </div>
            }
          </Card>
        </div>
      </div>
      
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-id="pb3f8thdg" data-path="pages/Home.js">
        <Card
          title="Prompts by Month"
          subtitle="Creation trend over time"
          icon={<i className="fas fa-chart-line" data-id="43wc85qd3" data-path="pages/Home.js"></i>}>
          <LineChart
            data={stats.promptsByMonth}
            xKey="month"
            yKey="count" />
        </Card>
        
        <Card
          title="Top Tags"
          subtitle="Most used tags"
          icon={<i className="fas fa-tags" data-id="ohpa7k703" data-path="pages/Home.js"></i>}>
          <BarChart
            data={stats.topTags}
            labelKey="name"
            valueKey="count" />
        </Card>
      </div>
      
      {/* Exit/Back Buttons */}
      <div className="mt-6 flex justify-end" data-id="oenozekre" data-path="pages/Home.js">
        <Button
          variant="outline"
          onClick={() => navigate(-1)}
          icon={<i className="fas fa-arrow-left" data-id="7rqqck9ch" data-path="pages/Home.js"></i>}>
          Back
        </Button>
      </div>
    </div>);

};

// Stats Card Component
const StatsCard = ({ title, value, icon, change, isPositive }) => {
  return (
    <div className="bg-darklight rounded-lg p-4 shadow-sm" data-id="1cig0z0yd" data-path="pages/Home.js">
      <div className="flex items-start justify-between" data-id="o0woz5iof" data-path="pages/Home.js">
        <div data-id="rx7am23ou" data-path="pages/Home.js">
          <h3 className="text-gray-400 text-sm font-medium mb-1" data-id="d3agxrax1" data-path="pages/Home.js">{title}</h3>
          <div className="text-2xl font-semibold text-white" data-id="xfu1yzsn7" data-path="pages/Home.js">{value}</div>
          {change &&
          <div className={`text-xs mt-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`} data-id="62o95vrfy" data-path="pages/Home.js">
              <i className={`fas fa-arrow-${isPositive ? 'up' : 'down'} mr-1`} data-id="r6tlktbbu" data-path="pages/Home.js"></i>
              {change}
            </div>
          }
        </div>
        <div className="text-primary text-xl opacity-80" data-id="4feisnj93" data-path="pages/Home.js">
          {icon}
        </div>
      </div>
    </div>);

};