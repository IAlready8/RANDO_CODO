// Categories and tags page

const Categories = () => {
  const { useState } = React;
  const { categories, tags, prompts, loading } = usePrompts();
  const [activeTab, setActiveTab] = useState('categories'); // categories, tags
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedTag, setSelectedTag] = useState(null);

  // Filter prompts by selected category
  const filteredPrompts = selectedCategory ?
  prompts.filter((prompt) => prompt.category === selectedCategory) :
  selectedTag ?
  prompts.filter((prompt) => prompt.tags.includes(selectedTag)) :
  [];

  // Handle category selection
  const handleCategorySelect = (category) => {
    setSelectedCategory(category.name);
    setSelectedTag(null);
    setActiveTab('prompts');
  };

  // Handle tag selection
  const handleTagSelect = (tag) => {
    setSelectedTag(tag.name);
    setSelectedCategory(null);
    setActiveTab('prompts');
  };

  // Go back to categories or tags
  const handleBack = () => {
    setSelectedCategory(null);
    setSelectedTag(null);
    setActiveTab('categories');
  };

  return (
    <div className="dashboard-container" data-id="rf2nv7qva" data-path="pages/Categories.js">
      <div className="dashboard-header" data-id="ih7b1iazr" data-path="pages/Categories.js">
        <h1 className="dashboard-title" data-id="hwnajq3po" data-path="pages/Categories.js">
          {selectedCategory ? `Category: ${selectedCategory}` :
          selectedTag ? `Tag: ${selectedTag}` :
          'Categories & Tags'}
        </h1>
        <div className="dashboard-actions" data-id="0o2zz06qc" data-path="pages/Categories.js">
          {selectedCategory || selectedTag ?
          <Button
            variant="ghost"
            icon={<i className="fas fa-arrow-left" data-id="h5c0anj3w" data-path="pages/Categories.js"></i>}
            onClick={handleBack}>

              Back
            </Button> :

          <div className="bg-darklight rounded-lg overflow-hidden" data-id="xf110i2y7" data-path="pages/Categories.js">
              <button
              className={`px-4 py-2 ${activeTab === 'categories' ? 'bg-primary text-white' : 'text-gray-400'}`}
              onClick={() => setActiveTab('categories')} data-id="jd82diqna" data-path="pages/Categories.js">

                <i className="fas fa-folder mr-2" data-id="cqdp9ys93" data-path="pages/Categories.js"></i>
                Categories
              </button>
              <button
              className={`px-4 py-2 ${activeTab === 'tags' ? 'bg-primary text-white' : 'text-gray-400'}`}
              onClick={() => setActiveTab('tags')} data-id="5hr8nnu8l" data-path="pages/Categories.js">

                <i className="fas fa-tags mr-2" data-id="hw8rplyvf" data-path="pages/Categories.js"></i>
                Tags
              </button>
            </div>
          }
        </div>
      </div>
      
      {/* Show prompts if category or tag is selected */}
      {selectedCategory || selectedTag ?
      <Card>
          <PromptList
          prompts={filteredPrompts}
          loading={loading}
          category={selectedCategory}
          tag={selectedTag} />

        </Card> : (

      /* Show categories or tags based on active tab */
      activeTab === 'categories' ?
      <Card>
            <CategoryList
          categories={categories}
          onCategorySelect={handleCategorySelect} />

          </Card> :

      <div data-id="o5esfl933" data-path="pages/Categories.js">
            <Card className="mb-6">
              <h3 className="text-lg font-medium mb-4" data-id="7s3r7prah" data-path="pages/Categories.js">Tag Cloud</h3>
              <TagCloud
            tags={tags}
            onTagSelect={handleTagSelect} />

            </Card>
            
            <Card>
              <h3 className="text-lg font-medium mb-4" data-id="5a634c2yv" data-path="pages/Categories.js">All Tags</h3>
              <TagList
            tags={tags}
            onTagSelect={handleTagSelect} />

            </Card>
          </div>)

      }
    </div>);

};