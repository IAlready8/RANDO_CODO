// Authentication page with login and registration

const AuthPage = () => {
  const { currentUser } = useAuth();
  const navigate = ReactRouterDOM.useNavigate();

  // Redirect to home if already logged in
  React.useEffect(() => {
    if (currentUser) {
      navigate('/');
    }
  }, [currentUser, navigate]);

  return (
    <div className="auth-container" data-id="vamwvpo6s" data-path="pages/AuthPage.js">
      <Auth />
    </div>);

};