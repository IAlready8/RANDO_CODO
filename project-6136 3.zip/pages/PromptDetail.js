// Prompt detail page to view and edit a single prompt

const PromptDetail = () => {
  const { useState, useEffect } = React;
  const { prompts, updatePrompt, deletePrompt } = usePrompts();
  const navigate = ReactRouterDOM.useNavigate();
  const params = ReactRouterDOM.useParams();
  const [prompt, setPrompt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  // Load prompt details on mount
  useEffect(() => {
    const loadPrompt = () => {
      const foundPrompt = prompts.find((p) => p.id === params.id);
      if (foundPrompt) {
        setPrompt(foundPrompt);
      } else {
        setError('Prompt not found');
      }
      setLoading(false);
    };

    if (prompts.length > 0) {
      loadPrompt();
    } else {
      setLoading(false);
      setError('No prompts available');
    }
  }, [params.id, prompts]);

  // Handle edit button click
  const handleEdit = () => {
    setIsEditing(true);
  };

  // Handle delete button click
  const handleDelete = () => {
    setShowDeleteModal(true);
  };

  // Handle confirm delete
  const handleConfirmDelete = async () => {
    try {
      await deletePrompt(prompt.id);
      navigate('/');
    } catch (error) {
      setError(`Failed to delete prompt: ${error.message}`);
    }
  };

  // Handle copy to clipboard
  const handleCopy = () => {
    copyToClipboard(prompt.content);

    // Show temporary copied message
    const message = document.createElement('div');
    message.textContent = 'Copied to clipboard!';
    message.className = 'fixed bottom-4 right-4 bg-primary text-white py-2 px-4 rounded-lg shadow-lg animate-fade-in';
    document.body.appendChild(message);

    setTimeout(() => {
      message.remove();
    }, 2000);
  };

  // Handle back button click
  const handleBack = () => {
    navigate(-1);
  };

  // If still loading
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64" data-id="a8vp0q2yw" data-path="pages/PromptDetail.js">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary" data-id="5wo25to7h" data-path="pages/PromptDetail.js"></div>
      </div>);

  }

  // If error or prompt not found
  if (error || !prompt) {
    return (
      <div className="empty-state" data-id="eamt264pt" data-path="pages/PromptDetail.js">
        <div className="empty-state-icon" data-id="5omne5sc1" data-path="pages/PromptDetail.js">
          <i className="fas fa-exclamation-circle" data-id="het69oe5z" data-path="pages/PromptDetail.js"></i>
        </div>
        <h3 className="empty-state-title" data-id="x1wonzrl3" data-path="pages/PromptDetail.js">Error</h3>
        <p className="empty-state-description" data-id="18y680dz3" data-path="pages/PromptDetail.js">{error || 'Prompt not found'}</p>
        <Button
          onClick={() => navigate('/')}
          variant="primary">
          Go to Dashboard
        </Button>
      </div>);

  }

  // If editing mode is on
  if (isEditing) {
    return (
      <div className="dashboard-container" data-id="05hv0ejdr" data-path="pages/PromptDetail.js">
        <div className="dashboard-header" data-id="8r2edvk0f" data-path="pages/PromptDetail.js">
          <div className="flex items-center" data-id="6oi861ls4" data-path="pages/PromptDetail.js">
            <button
              className="mr-3 text-gray-400 hover:text-white"
              onClick={() => setIsEditing(false)} data-id="gy9gpy61f" data-path="pages/PromptDetail.js">

              <i className="fas fa-arrow-left text-xl" data-id="ng4hgwriy" data-path="pages/PromptDetail.js"></i>
            </button>
            <h1 className="dashboard-title" data-id="fwnn06vvk" data-path="pages/PromptDetail.js">Edit Prompt</h1>
          </div>
          <div className="dashboard-actions" data-id="4rj0bifcq" data-path="pages/PromptDetail.js">
            <Button
              variant="ghost"
              onClick={() => setIsEditing(false)}
              icon={<i className="fas fa-times" data-id="j09d65sdn" data-path="pages/PromptDetail.js"></i>}>
              Cancel
            </Button>
          </div>
        </div>
        
        <PromptInput existingPrompt={prompt} />
      </div>);

  }

  // Regular view mode
  return (
    <div className="dashboard-container" data-id="lek8lnzvc" data-path="pages/PromptDetail.js">
      <div className="dashboard-header" data-id="0lqyt95dx" data-path="pages/PromptDetail.js">
        <div className="flex items-center" data-id="gkyldkwm5" data-path="pages/PromptDetail.js">
          <button
            className="mr-3 text-gray-400 hover:text-white"
            onClick={handleBack} data-id="zpcnce0ii" data-path="pages/PromptDetail.js">

            <i className="fas fa-arrow-left text-xl" data-id="41bcbs91w" data-path="pages/PromptDetail.js"></i>
          </button>
          <h1 className="dashboard-title" data-id="wqpkk81uc" data-path="pages/PromptDetail.js">{prompt.title}</h1>
        </div>
        <div className="dashboard-actions flex gap-2" data-id="9dedxgize" data-path="pages/PromptDetail.js">
          <Button
            variant="ghost"
            onClick={handleCopy}
            icon={<i className="fas fa-copy" data-id="a5egalpyk" data-path="pages/PromptDetail.js"></i>}>
            Copy
          </Button>
          <Button
            variant="outline"
            onClick={handleEdit}
            icon={<i className="fas fa-edit" data-id="nw3yrwkjq" data-path="pages/PromptDetail.js"></i>}>
            Edit
          </Button>
          <Button
            variant="danger"
            onClick={handleDelete}
            icon={<i className="fas fa-trash-alt" data-id="n2drg4hn3" data-path="pages/PromptDetail.js"></i>}>
            Delete
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-id="1qxnztzbl" data-path="pages/PromptDetail.js">
        <div className="lg:col-span-2" data-id="x0r3a9yib" data-path="pages/PromptDetail.js">
          {/* Prompt Content Card */}
          <Card
            className="mb-6">
            <div className="p-4 whitespace-pre-wrap bg-darklight bg-opacity-50 rounded border border-gray-700 text-gray-200" data-id="gnrz82vjt" data-path="pages/PromptDetail.js">
              {prompt.content}
            </div>
          </Card>
          
          {/* Usage Example */}
          <Card
            title="Usage Example"
            icon={<i className="fas fa-magic" data-id="6vxlcfsz9" data-path="pages/PromptDetail.js"></i>}
            className="mb-6">
            <div className="bg-gray-900 p-4 rounded-lg" data-id="2o30wxjfs" data-path="pages/PromptDetail.js">
              <div className="mb-4" data-id="4o53s331n" data-path="pages/PromptDetail.js">
                <p className="text-gray-400 mb-2" data-id="h7co6jqn2" data-path="pages/PromptDetail.js">Send this prompt to AI:</p>
                <div className="bg-darklight p-3 rounded border border-gray-700 mb-4" data-id="gxivsbj3z" data-path="pages/PromptDetail.js">
                  <p className="text-gray-300" data-id="t7pg9qo3j" data-path="pages/PromptDetail.js">{truncateText(prompt.content, 200)}</p>
                </div>
                <Button
                  size="sm"
                  onClick={handleCopy}>
                  <i className="fas fa-copy mr-2" data-id="mk230ygdj" data-path="pages/PromptDetail.js"></i> Copy to Use
                </Button>
              </div>
              
              <div data-id="ifze5c0jm" data-path="pages/PromptDetail.js">
                <p className="text-gray-400 mb-2" data-id="oc8sqqb12" data-path="pages/PromptDetail.js">Example response:</p>
                <div className="bg-darklight p-3 rounded border border-gray-700 text-gray-300" data-id="uf91yaqao" data-path="pages/PromptDetail.js">
                  <p data-id="z3t520wot" data-path="pages/PromptDetail.js">This is an example of how an AI might respond to your prompt. The actual response would depend on the AI service you're using and the specific prompt content.</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
        
        <div data-id="8m3yiomeg" data-path="pages/PromptDetail.js">
          {/* Prompt Details Card */}
          <Card
            title="Prompt Details"
            className="mb-6">
            <div className="p-4" data-id="ounk167lp" data-path="pages/PromptDetail.js">
              <div className="mb-4" data-id="tt2bsw4t7" data-path="pages/PromptDetail.js">
                <h3 className="text-sm text-gray-400" data-id="vs3th2vk2" data-path="pages/PromptDetail.js">Category</h3>
                <div className="prompt-category mt-1" data-id="9metup0rw" data-path="pages/PromptDetail.js">{prompt.category}</div>
              </div>
              
              <div className="mb-4" data-id="fujoy8vzm" data-path="pages/PromptDetail.js">
                <h3 className="text-sm text-gray-400" data-id="pxx1n6xpv" data-path="pages/PromptDetail.js">Tags</h3>
                <div className="flex flex-wrap gap-2 mt-1" data-id="jljiypkgh" data-path="pages/PromptDetail.js">
                  {prompt.tags && prompt.tags.map((tag, index) =>
                  <div key={index} className="prompt-tag" data-id="5wwam83zg" data-path="pages/PromptDetail.js">
                      {tag}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mb-4" data-id="9cmqn3gbq" data-path="pages/PromptDetail.js">
                <h3 className="text-sm text-gray-400" data-id="v59epyeyt" data-path="pages/PromptDetail.js">Created</h3>
                <p data-id="r8xi4m6y3" data-path="pages/PromptDetail.js">{formatDateTime(prompt.createdAt)}</p>
              </div>
              
              <div className="mb-4" data-id="lqr5og4mm" data-path="pages/PromptDetail.js">
                <h3 className="text-sm text-gray-400" data-id="1iofsf015" data-path="pages/PromptDetail.js">Last Updated</h3>
                <p data-id="8np0cjzzx" data-path="pages/PromptDetail.js">{formatDateTime(prompt.updatedAt)}</p>
              </div>
              
              <div data-id="vns80spag" data-path="pages/PromptDetail.js">
                <h3 className="text-sm text-gray-400" data-id="p9cx1n20g" data-path="pages/PromptDetail.js">Usage Count</h3>
                <p data-id="ael2yhvbc" data-path="pages/PromptDetail.js">{prompt.usage} times</p>
              </div>
            </div>
          </Card>
          
          {/* Related Actions Card */}
          <Card
            title="Actions">
            <div className="p-4 space-y-2" data-id="8q77tuk50" data-path="pages/PromptDetail.js">
              <Button
                fullWidth
                variant="outline"
                icon={<i className="fas fa-play" data-id="egb3yoesl" data-path="pages/PromptDetail.js"></i>}>
                Test with AI
              </Button>
              
              <Button
                fullWidth
                variant="outline"
                icon={<i className="fas fa-share-alt" data-id="fcgoldcap" data-path="pages/PromptDetail.js"></i>}>
                Share Prompt
              </Button>
              
              <Button
                fullWidth
                variant="outline"
                icon={<i className="fas fa-clone" data-id="nktphijyo" data-path="pages/PromptDetail.js"></i>}>
                Duplicate
              </Button>
              
              <Button
                fullWidth
                variant="primary"
                icon={<i className="fas fa-save" data-id="cpxx3m4ii" data-path="pages/PromptDetail.js"></i>}>
                Save Changes
              </Button>
              
              <Button
                fullWidth
                variant="outline"
                icon={<i className="fas fa-sign-out-alt" data-id="p50x5vrqt" data-path="pages/PromptDetail.js"></i>}
                onClick={handleBack}>
                Exit
              </Button>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Prompt"
        message="Are you sure you want to delete this prompt? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger" />
    </div>);

};