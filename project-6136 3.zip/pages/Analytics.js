// Analytics page with charts and statistics

const Analytics = () => {
  const { useState, useEffect } = React;
  const { prompts, loading, getAnalytics } = usePrompts();

  const [stats, setStats] = useState({
    totalPrompts: 0,
    promptsByCategory: [],
    promptsByMonth: [],
    topTags: []
  });

  const [timeRange, setTimeRange] = useState('all'); // all, month, week

  // Load analytics data
  useEffect(() => {
    const analytics = getAnalytics();
    setStats(analytics);
  }, [prompts, timeRange]);

  // Get date from X months ago
  const getDateXMonthsAgo = (months) => {
    const date = new Date();
    date.setMonth(date.getMonth() - months);
    return date;
  };

  // Filter data by time range
  const filterDataByTimeRange = (data) => {
    if (timeRange === 'all') return data;

    const comparisonDate = timeRange === 'month' ?
    getDateXMonthsAgo(1) :
    new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    return prompts.filter((prompt) => new Date(prompt.createdAt) >= comparisonDate);
  };

  // Calculate average prompts per day/week/month
  const calculateAverages = () => {
    if (prompts.length === 0) {
      return { perDay: 0, perWeek: 0, perMonth: 0 };
    }

    // Sort by date
    const sortedPrompts = [...prompts].sort((a, b) =>
    new Date(a.createdAt) - new Date(b.createdAt)
    );

    const firstDate = new Date(sortedPrompts[0].createdAt);
    const lastDate = new Date();

    // Calculate total days
    const totalDays = Math.max(1, Math.ceil((lastDate - firstDate) / (1000 * 60 * 60 * 24)));

    const perDay = prompts.length / totalDays;
    const perWeek = perDay * 7;
    const perMonth = perDay * 30;

    return {
      perDay: perDay.toFixed(1),
      perWeek: perWeek.toFixed(1),
      perMonth: perMonth.toFixed(1)
    };
  };

  const averages = calculateAverages();

  return (
    <div className="dashboard-container" data-id="33l0271gc" data-path="pages/Analytics.js">
      <div className="dashboard-header" data-id="7bq4qrpk0" data-path="pages/Analytics.js">
        <h1 className="dashboard-title" data-id="ebibsgb2z" data-path="pages/Analytics.js">Analytics</h1>
        <div className="dashboard-actions" data-id="3dfr5w3v6" data-path="pages/Analytics.js">
          <select
            className="bg-darklight border border-gray-700 text-white rounded-md text-sm p-2"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)} data-id="b5pdmqhri" data-path="pages/Analytics.js">

            <option value="all" data-id="027vpnutf" data-path="pages/Analytics.js">All Time</option>
            <option value="month" data-id="vnrukppjk" data-path="pages/Analytics.js">Last Month</option>
            <option value="week" data-id="jx136sdwo" data-path="pages/Analytics.js">Last Week</option>
          </select>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6" data-id="wb15y09m8" data-path="pages/Analytics.js">
        <StatsCard
          title="Total Prompts"
          value={stats.totalPrompts}
          icon={<i className="fas fa-file-alt" data-id="7wxajmw1w" data-path="pages/Analytics.js"></i>} />

        
        <StatsCard
          title="Avg. Per Day"
          value={averages.perDay}
          icon={<i className="fas fa-calendar-day" data-id="qv6cfci65" data-path="pages/Analytics.js"></i>} />

        
        <StatsCard
          title="Avg. Per Week"
          value={averages.perWeek}
          icon={<i className="fas fa-calendar-week" data-id="5dwe5kg7y" data-path="pages/Analytics.js"></i>} />

        
        <StatsCard
          title="Avg. Per Month"
          value={averages.perMonth}
          icon={<i className="fas fa-calendar-alt" data-id="yeocakzzp" data-path="pages/Analytics.js"></i>} />

      </div>
      
      {/* Main Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6" data-id="itsstsgiy" data-path="pages/Analytics.js">
        <Card
          title="Prompts by Month"
          subtitle="Creation trend over time">

          <LineChart
            data={stats.promptsByMonth}
            xKey="month"
            yKey="count" />

        </Card>
        
        <Card
          title="Category Distribution"
          subtitle="Prompts by category">

          <PieChart
            data={stats.promptsByCategory}
            labelKey="name"
            valueKey="value" />

        </Card>
      </div>
      
      {/* Tag Analysis */}
      <Card
        title="Tag Analysis"
        subtitle="Most used tags in your prompts"
        className="mb-6">

        <BarChart
          data={stats.topTags}
          labelKey="name"
          valueKey="count" />

      </Card>
      
      {/* Detailed Stats */}
      <Card
        title="Usage Statistics"
        subtitle="Detailed prompt usage data">

        <div className="overflow-x-auto" data-id="emrqm5a12" data-path="pages/Analytics.js">
          <table className="w-full text-sm text-left text-gray-300" data-id="a8ojub8kd" data-path="pages/Analytics.js">
            <thead className="text-xs uppercase bg-gray-800 text-gray-400" data-id="ht0yhamvk" data-path="pages/Analytics.js">
              <tr data-id="2pi1qz9y1" data-path="pages/Analytics.js">
                <th className="px-4 py-3" data-id="docpp2lgt" data-path="pages/Analytics.js">Metric</th>
                <th className="px-4 py-3" data-id="j8ytq5129" data-path="pages/Analytics.js">Value</th>
                <th className="px-4 py-3" data-id="keo7saysf" data-path="pages/Analytics.js">Details</th>
              </tr>
            </thead>
            <tbody data-id="47sgh9kua" data-path="pages/Analytics.js">
              <tr className="border-b border-gray-700" data-id="w9aers9dd" data-path="pages/Analytics.js">
                <td className="px-4 py-3" data-id="xijh1wmpt" data-path="pages/Analytics.js">Total Prompts</td>
                <td className="px-4 py-3" data-id="yd197iax9" data-path="pages/Analytics.js">{stats.totalPrompts}</td>
                <td className="px-4 py-3 text-gray-400" data-id="auxu46gma" data-path="pages/Analytics.js">Total number of prompts created</td>
              </tr>
              <tr className="border-b border-gray-700" data-id="cbrp993je" data-path="pages/Analytics.js">
                <td className="px-4 py-3" data-id="6w882rbra" data-path="pages/Analytics.js">Categories</td>
                <td className="px-4 py-3" data-id="qpburumuo" data-path="pages/Analytics.js">{stats.promptsByCategory.length}</td>
                <td className="px-4 py-3 text-gray-400" data-id="qbjj3d0ac" data-path="pages/Analytics.js">Total unique categories</td>
              </tr>
              <tr className="border-b border-gray-700" data-id="vfskqtfng" data-path="pages/Analytics.js">
                <td className="px-4 py-3" data-id="tldcfbbuh" data-path="pages/Analytics.js">Tags</td>
                <td className="px-4 py-3" data-id="dskpy24vv" data-path="pages/Analytics.js">{stats.topTags.length}</td>
                <td className="px-4 py-3 text-gray-400" data-id="ta0krdhaf" data-path="pages/Analytics.js">Total unique tags</td>
              </tr>
              <tr className="border-b border-gray-700" data-id="uo018bbee" data-path="pages/Analytics.js">
                <td className="px-4 py-3" data-id="5yauobx8l" data-path="pages/Analytics.js">Most Active Month</td>
                <td className="px-4 py-3" data-id="quqirnaif" data-path="pages/Analytics.js">
                  {stats.promptsByMonth.length > 0 ?
                  stats.promptsByMonth.reduce((max, month) =>
                  month.count > max.count ? month : max, stats.promptsByMonth[0]
                  ).month :
                  'N/A'
                  }
                </td>
                <td className="px-4 py-3 text-gray-400" data-id="pnqraejgm" data-path="pages/Analytics.js">Month with the most prompt creations</td>
              </tr>
              <tr data-id="lze2ij29v" data-path="pages/Analytics.js">
                <td className="px-4 py-3" data-id="3i8x6gy1t" data-path="pages/Analytics.js">First Prompt</td>
                <td className="px-4 py-3" data-id="tqr3f17zo" data-path="pages/Analytics.js">
                  {prompts.length > 0 ?
                  formatDate([...prompts].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))[0].createdAt) :
                  'N/A'
                  }
                </td>
                <td className="px-4 py-3 text-gray-400" data-id="8bovurym9" data-path="pages/Analytics.js">Date of first prompt creation</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>);

};