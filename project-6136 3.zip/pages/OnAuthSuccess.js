// OnAuthSuccess page - displayed after successful registration and email verification

const OnAuthSuccess = () => {
  const [countdown, setCountdown] = React.useState(5);
  const navigate = ReactRouterDOM.useNavigate();

  React.useEffect(() => {
    // Start countdown
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/auth');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div className="flex items-center justify-center h-screen bg-dark" data-id="8pkmxbh2q" data-path="pages/OnAuthSuccess.js">
      <div className="text-center" data-id="4gonzoc9h" data-path="pages/OnAuthSuccess.js">
        <h1 className="text-3xl font-bold text-primary mb-4" data-id="eqytsdwmz" data-path="pages/OnAuthSuccess.js">Registration Successful!</h1>
        <p className="text-xl text-white mb-8" data-id="o0pmy3ubm" data-path="pages/OnAuthSuccess.js">Your account has been verified.</p>
        <p className="text-white mb-6" data-id="85afwnkks" data-path="pages/OnAuthSuccess.js">Redirecting to login page in <span id="countdown" data-id="xqm1xivhj" data-path="pages/OnAuthSuccess.js">{countdown}</span> seconds...</p>
        <Button
          onClick={() => navigate('/auth')}>
          Login Now
        </Button>
      </div>
    </div>);

};