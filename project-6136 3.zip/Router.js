// Router configuration

const Router = () => {
  console.log('Router loaded');
  const { useState } = React;
  const { currentUser } = useAuth();

  // Private route wrapper
  const PrivateRoute = ({ children }) => {
    const navigate = ReactRouterDOM.useNavigate();

    React.useEffect(() => {
      if (!currentUser) {
        navigate('/auth');
      }
    }, [currentUser, navigate]);

    return currentUser ? children : null;
  };

  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Toggle sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Main layout wrapper
  const MainLayout = ({ children }) => {
    return (
      <div className="app-container" data-id="pen1miou3" data-path="Router.js">
        <Sidebar
          isOpen={sidebarOpen}
          toggleSidebar={toggleSidebar} />

        <div className={`content-area ${!sidebarOpen ? 'sidebar-collapsed' : ''}`} data-id="x53yj7avo" data-path="Router.js">
          <Navbar toggleSidebar={toggleSidebar} />
          <div className="p-4" data-id="klhlm66qi" data-path="Router.js">
            {children}
          </div>
        </div>
      </div>);

  };

  return (
    <ReactRouterDOM.Routes>
      {/* Public Routes */}
      <ReactRouterDOM.Route path="/auth" element={<AuthPage />} />
      
      {/* Private Routes */}
      <ReactRouterDOM.Route
        path="/"
        element={
        <PrivateRoute>
            <MainLayout>
              <Home />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/analytics"
        element={
        <PrivateRoute>
            <MainLayout>
              <Analytics />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/categories"
        element={
        <PrivateRoute>
            <MainLayout>
              <Categories />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/categories/:category"
        element={
        <PrivateRoute>
            <MainLayout>
              <Categories />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/tags"
        element={
        <PrivateRoute>
            <MainLayout>
              <Categories view="tags" />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/tags/:tag"
        element={
        <PrivateRoute>
            <MainLayout>
              <Categories view="tags" />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/settings"
        element={
        <PrivateRoute>
            <MainLayout>
              <Settings />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/new-prompt"
        element={
        <PrivateRoute>
            <MainLayout>
              <div className="dashboard-container" data-id="ullmkdx15" data-path="Router.js">
                <div className="dashboard-header" data-id="toa1uq5qz" data-path="Router.js">
                  <div className="flex items-center" data-id="ec1dlexuu" data-path="Router.js">
                    <button
                    className="mr-3 text-gray-400 hover:text-white"
                    onClick={() => window.history.back()} data-id="x78e6ds9b" data-path="Router.js">

                      <i className="fas fa-arrow-left text-xl" data-id="o2xj1msey" data-path="Router.js"></i>
                    </button>
                    <h1 className="dashboard-title" data-id="u5oywhw7h" data-path="Router.js">Create New Prompt</h1>
                  </div>
                </div>
                <Card>
                  <PromptInput />
                </Card>
              </div>
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/edit-prompt/:id"
        element={
        <PrivateRoute>
            <MainLayout>
              <PromptDetail />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/prompt/:id"
        element={
        <PrivateRoute>
            <MainLayout>
              <PromptDetail />
            </MainLayout>
          </PrivateRoute>
        } />

      <ReactRouterDOM.Route
        path="/history"
        element={
        <PrivateRoute>
            <MainLayout>
              <div className="dashboard-container" data-id="v3mipp193" data-path="Router.js">
                <div className="dashboard-header" data-id="65pux0y6e" data-path="Router.js">
                  <div className="flex items-center" data-id="9605iq61q" data-path="Router.js">
                    <button
                    className="mr-3 text-gray-400 hover:text-white"
                    onClick={() => window.history.back()} data-id="gjwa9htma" data-path="Router.js">

                      <i className="fas fa-arrow-left text-xl" data-id="4w44g5zwm" data-path="Router.js"></i>
                    </button>
                    <h1 className="dashboard-title" data-id="brhuu8kqg" data-path="Router.js">Usage History</h1>
                  </div>
                  <div className="dashboard-actions" data-id="96ksuoydx" data-path="Router.js">
                    <Button
                    variant="outline"
                    icon={<i className="fas fa-save" data-id="qn5srq69x" data-path="Router.js"></i>}>
                      Save
                    </Button>
                  </div>
                </div>
                <Card>
                  <div className="empty-state" data-id="orzswvf9e" data-path="Router.js">
                    <div className="empty-state-icon" data-id="t5xxvs7x5" data-path="Router.js">
                      <i className="fas fa-history" data-id="ett53nxh7" data-path="Router.js"></i>
                    </div>
                    <h3 className="empty-state-title" data-id="sbz5tdi4s" data-path="Router.js">No Usage History</h3>
                    <p className="empty-state-description" data-id="b7djtaw8o" data-path="Router.js">
                      Your prompt usage history will appear here
                    </p>
                  </div>
                </Card>
              </div>
            </MainLayout>
          </PrivateRoute>
        } />

      {/* 404 Not Found */}
      <ReactRouterDOM.Route
        path="*"
        element={
        <div className="flex items-center justify-center h-screen bg-dark" data-id="ffmcclrqh" data-path="Router.js">
            <div className="text-center" data-id="e0yzdsbig" data-path="Router.js">
              <h1 className="text-6xl font-bold text-primary mb-4" data-id="o3h3xx5gp" data-path="Router.js">404</h1>
              <h2 className="text-2xl text-white mb-6" data-id="1cruuf6iz" data-path="Router.js">Page Not Found</h2>
              <Button
              onClick={() => window.location.href = '/'}>
                Go to Dashboard
              </Button>
            </div>
          </div>
        } />

      {/* Auth-specific routes */}
      <ReactRouterDOM.Route
        path="/onauthsuccess"
        element={
        <OnAuthSuccess />
        } />

      <ReactRouterDOM.Route
        path="/resetpassword"
        element={
        <ResetPassword />
        } />
    </ReactRouterDOM.Routes>);

};